import { ID } from "./constants.js";
import { buildArea } from "./aoeGeometryCore.js";
import { AOE_AREA_META_KEY } from "./aoeStyle.js";
import { clipChildZoneAreaToParent } from "./spellChildZoneCore.js";

export const SPELL_STATIC_ZONE_META_KEY = `${ID}/spellStaticZone`;
export const SPELL_ZONE_MOVEMENT_CONTROL_FIELD = "movementControl";

const normalizedId = (value) => String(value || "").trim();
const clone = (value) => {
  if (value === undefined) return undefined;
  if (typeof globalThis.structuredClone === "function") return globalThis.structuredClone(value);
  return JSON.parse(JSON.stringify(value));
};
const normalizedIds = (values = []) => Array.from(new Set(
  (Array.isArray(values) ? values : [])
    .map(normalizedId)
    .filter(Boolean),
));

const point = (value) => {
  const x = Number(value?.x);
  const y = Number(value?.y);
  return Number.isFinite(x) && Number.isFinite(y) ? { x, y } : null;
};

export function spellStaticZoneFollowCasterPosition(metadata, casterPosition) {
  if (metadata?.followCaster !== true) return null;
  const caster = point(casterPosition);
  const casterOrigin = point(metadata.casterOrigin);
  if (!caster || !casterOrigin) return null;
  const zoneOrigin = point(metadata.zoneOrigin) || { x: 0, y: 0 };
  return {
    x: zoneOrigin.x + caster.x - casterOrigin.x,
    y: zoneOrigin.y + caster.y - casterOrigin.y,
  };
}

export function translatedZoneArea(item, positionOverride = null) {
  const metadata = item?.metadata?.[AOE_AREA_META_KEY];
  if (!metadata?.type || !metadata?.start || !metadata?.end) return null;
  const position = point(positionOverride || item.position) || { x: 0, y: 0 };
  const base = point(metadata.basePosition) || { x: 0, y: 0 };
  const delta = { x: position.x - base.x, y: position.y - base.y };
  const translate = (entry) => ({
    x: Number(entry.x) + delta.x,
    y: Number(entry.y) + delta.y,
  });
  let area = buildArea(
    metadata.type,
    translate(metadata.start),
    translate(metadata.end),
    metadata.dpi,
    translate(metadata.gridOrigin || metadata.start),
    {
      widthSquares: metadata.widthSquares,
      widthAnchor: metadata.widthAnchor,
      ...(metadata.ring === true
        ? { ring: true, ringInnerSquares: metadata.ringInnerSquares }
        : {}),
    },
  );
  if (metadata.parentClip && typeof metadata.parentClip === "object") {
    area = clipChildZoneAreaToParent({
      parentArea: metadata.parentClip,
      childArea: area,
    });
  }
  if (metadata.centerlineStart && metadata.centerlineEnd) {
    area.centerlineStart = point(metadata.centerlineStart);
    area.centerlineEnd = point(metadata.centerlineEnd);
  }
  return area;
}

export function translatedZoneTriggerAreas(item, positionOverride = null) {
  const body = translatedZoneArea(item, positionOverride);
  if (!body) return { body: null, hotBand: null };
  const metadata = item?.metadata?.[AOE_AREA_META_KEY] || {};
  const hotBand = metadata.hotBand && typeof metadata.hotBand === "object"
    ? buildArea(
      metadata.type,
      point(metadata.start) || { x: 0, y: 0 },
      point(metadata.end) || { x: 0, y: 0 },
      metadata.dpi,
      point(metadata.gridOrigin || metadata.start) || { x: 0, y: 0 },
      {
        widthSquares: metadata.widthSquares,
        widthAnchor: metadata.widthAnchor,
        ...(metadata.ring === true
          ? { ringInnerSquares: metadata.ringInnerSquares }
          : {}),
        band: {
          side: metadata.hotBand.side,
          bandSquares: metadata.hotBand.widthSquares,
        },
      },
    )
    : null;
  if (!hotBand) return { body, hotBand: null };
  const position = point(positionOverride || item?.position) || { x: 0, y: 0 };
  const base = point(metadata.basePosition) || { x: 0, y: 0 };
  const delta = { x: position.x - base.x, y: position.y - base.y };
  const translateCells = (area) => ({
    ...area,
    origin: area.origin
      ? { x: area.origin.x + delta.x, y: area.origin.y + delta.y }
      : area.origin,
    cells: Array.isArray(area.cells)
      ? area.cells.map((cell) => ({
        ...cell,
        x: cell.x + delta.x,
        y: cell.y + delta.y,
      }))
      : area.cells,
    ...(Array.isArray(area.points)
      ? {
        points: area.points.map((entry) => ({
          x: entry.x + delta.x,
          y: entry.y + delta.y,
        })),
      }
      : {}),
  });
  return { body, hotBand: translateCells(hotBand) };
}

export function staticSpellZoneMetadata({
  instanceId = "",
  ruleId = "",
  spellId = "",
  casterId = "",
  role = "root",
  parentId = "",
  ruleChoice = "",
  targetIds = [],
  exemptCreatureIds = [],
  followCaster = false,
  casterOrigin = null,
  zoneOrigin = null,
} = {}) {
  const metadata = {
    version: 1,
    instanceId: normalizedId(instanceId),
    ruleId: normalizedId(ruleId),
    spellId: normalizedId(spellId),
    casterId: normalizedId(casterId),
    role: ["geometry", "subzone"].includes(role) ? role : "root",
  };
  const normalizedParentId = normalizedId(parentId);
  if (normalizedParentId) metadata.parentId = normalizedParentId;
  const normalizedRuleChoice = normalizedId(ruleChoice);
  if (normalizedRuleChoice) metadata.ruleChoice = normalizedRuleChoice;
  const scopedTargetIds = normalizedIds(targetIds);
  metadata.targetIds = scopedTargetIds;
  const scopedExemptCreatureIds = normalizedIds(exemptCreatureIds);
  if (scopedExemptCreatureIds.length) metadata.exemptCreatureIds = scopedExemptCreatureIds;
  if (followCaster === true) {
    metadata.followCaster = true;
    const normalizedCasterOrigin = point(casterOrigin);
    if (normalizedCasterOrigin) metadata.casterOrigin = normalizedCasterOrigin;
    const normalizedZoneOrigin = point(zoneOrigin);
    if (normalizedZoneOrigin) metadata.zoneOrigin = normalizedZoneOrigin;
  }
  return metadata;
}

export function scopedStaticSpellZoneTargetIds({
  rule = null,
  zoneMetadata = null,
  targetIds = [],
} = {}) {
  const candidates = normalizedIds(targetIds);
  const exemptCreatureIds = new Set(normalizedIds(zoneMetadata?.exemptCreatureIds));
  const withoutExemptions = candidates.filter((targetId) => !exemptCreatureIds.has(targetId));
  if (rule?.zonePolicy?.targetScope !== "spell-targets") return withoutExemptions;
  const spellTargets = new Set(normalizedIds(zoneMetadata?.targetIds));
  return withoutExemptions.filter((targetId) => spellTargets.has(targetId));
}

export function isStaticSpellZoneRule(rule) {
  return rule?.kind === "zone"
    && rule?.lifecycle?.persistence === "spell"
    && rule?.lifecycle?.endsWithSpell === true;
}

export function staticSpellZoneOwnerOperation({
  rule = null,
  spell = null,
  instanceId = "",
  casterId = "",
  appliedAt = null,
  trackConcentration = false,
  ruleChoice = "",
  slotLevel = null,
  summaryParts = null,
  castContext = null,
} = {}) {
  const normalizedInstanceId = normalizedId(instanceId);
  const normalizedCasterId = normalizedId(casterId);
  const concentration = spell?.concentration === true;
  if (
    !isStaticSpellZoneRule(rule)
    || (concentration && trackConcentration !== true)
    || !normalizedInstanceId
    || !normalizedCasterId
  ) {
    return null;
  }
  const name = String(spell?.displayName || spell?.name || "").trim();
  const spellId = normalizedId(spell?.id || rule.spellId);
  if (!name || !spellId) return null;
  const defaultTurns = Math.floor(Number(spell?.defaultTurns));
  const hasFiniteDuration = Number.isFinite(defaultTurns) && defaultTurns > 0;
  return {
    type: "spell:upsert",
    targetIds: [normalizedCasterId],
    ...(rule?.zonePolicy?.ownerLabelTargets === "none"
      ? { targets: [] }
      : {}),
    name,
    turns: hasFiniteDuration ? defaultTurns : 1,
    conc: concentration,
    source: normalizedCasterId,
    instanceId: normalizedInstanceId,
    spellId,
    ...(concentration
      ? { expiry: { mode: "concentration" } }
      : spell?.expiry && typeof spell.expiry === "object"
        ? { expiry: { ...spell.expiry } }
        : hasFiniteDuration
          ? {}
          : { expiry: { mode: "manual" } }),
    ...(appliedAt ? { appliedAt: { ...appliedAt } } : {}),
    castContext: {
      staticZoneOwner: true,
      staticZoneRuleId: rule.id,
      ...(slotLevel !== null && slotLevel !== "" && Number.isInteger(Number(slotLevel))
        ? { slotLevel: Number(slotLevel) }
        : {}),
      ...(normalizedId(ruleChoice)
        ? { choice: normalizedId(ruleChoice) }
        : {}),
      ...(castContext && typeof castContext === "object"
        ? clone(castContext)
        : {}),
    },
    ...(Array.isArray(summaryParts) && summaryParts.length
      ? { summaryParts: summaryParts.map((part) => ({ ...part })) }
      : {}),
    replaceNames: [name],
  };
}

export function staticSpellZoneItems(items = [], {
  instanceId = "",
  casterId = "",
} = {}) {
  const wantedInstanceId = normalizedId(instanceId);
  const wantedCasterId = normalizedId(casterId);
  return (Array.isArray(items) ? items : []).filter((item) => {
    const metadata = item?.metadata?.[SPELL_STATIC_ZONE_META_KEY];
    if (!metadata?.instanceId) return false;
    if (wantedInstanceId && normalizedId(metadata.instanceId) !== wantedInstanceId) return false;
    if (wantedCasterId && normalizedId(metadata.casterId) !== wantedCasterId) return false;
    return true;
  });
}

export function staticSpellZoneItemsEndedByPlan(zoneItems = [], plan = null) {
  const beforeActive = new Set();
  const afterActive = new Set();
  for (const change of Array.isArray(plan?.changes) ? plan.changes : []) {
    for (const spell of Array.isArray(change?.before?.spells)
      ? change.before.spells
      : []) {
      const instanceId = normalizedId(spell?.instanceId);
      if (instanceId) beforeActive.add(instanceId);
    }
    for (const concentration of Object.values(
      change?.before?.concentrations || {}
    )) {
      const instanceId = normalizedId(concentration?.instanceId);
      if (instanceId) beforeActive.add(instanceId);
    }
    for (const spell of Array.isArray(change?.after?.spells)
      ? change.after.spells
      : []) {
      const instanceId = normalizedId(spell?.instanceId);
      if (instanceId) afterActive.add(instanceId);
    }
    for (const concentration of Object.values(
      change?.after?.concentrations || {}
    )) {
      const instanceId = normalizedId(concentration?.instanceId);
      if (instanceId) afterActive.add(instanceId);
    }
  }
  return staticSpellZoneItems(zoneItems).filter((item) => {
    const instanceId = normalizedId(
      item.metadata[SPELL_STATIC_ZONE_META_KEY]?.instanceId
    );
    return beforeActive.has(instanceId) && !afterActive.has(instanceId);
  });
}

export function activeSpellInstanceIds(items = [], {
  metaKey = `${ID}/meta`,
  spellsKey = `${ID}/spells`,
  concentrationKey = `${ID}/concentration`,
} = {}) {
  const active = new Set();
  for (const item of Array.isArray(items) ? items : []) {
    const meta = item?.metadata?.[metaKey] || {};
    for (const spell of Array.isArray(meta?.[spellsKey]) ? meta[spellsKey] : []) {
      const instanceId = normalizedId(spell?.instanceId);
      if (instanceId) active.add(instanceId);
    }
    const concentration = meta?.[concentrationKey];
    if (!concentration || typeof concentration !== "object") continue;
    for (const entry of Object.values(concentration)) {
      const instanceId = normalizedId(entry?.instanceId);
      if (instanceId) active.add(instanceId);
    }
  }
  return active;
}

export function staleStaticSpellZoneItemIds(items = [], options = {}) {
  const active = activeSpellInstanceIds(items, options);
  const protectedInstanceIds = new Set(normalizedIds(options.protectedInstanceIds));
  return staticSpellZoneItems(items)
    .filter((item) => {
      const instanceId = normalizedId(
        item.metadata[SPELL_STATIC_ZONE_META_KEY].instanceId,
      );
      return !active.has(instanceId) && !protectedInstanceIds.has(instanceId);
    })
    .map((item) => item.id)
    .filter(Boolean);
}

  // src/contextMenu.js
  import {
    cleanupOwnedElevationLabels,
    mountElevationLabelWatcher,
    reconcileAllElevationLabels,
    unmountElevationLabelWatcher,
  } from "./elevationLabel.js";
  import OBR from "@owlbear-rodeo/sdk";
  import { ID } from "./constants.js";
  import { openTrackedPopover } from "./popoverDragHost.js";
  import {
    enqueueInitiativeStateReducer,
    nextInitiativeStateCommandId,
  } from "./initiativeStateGateway.js";
  import { currentSceneEpoch, isCurrentSceneEpoch } from "./sceneEpoch.js";
  import { createParagonToggleExecutor } from "./paragonToggleCore.js";
  import { runtimeOptionsService } from "./options/optionsRuntime.js";
  import { selectElevationLabelsEnabled } from "./options/optionsSelectors.js";
  import {
    bindOptionalRuntimeOption,
    createOptionalRuntimeLifecycle,
  } from "./options/optionalRuntimeLifecycle.js";
  export { ID }; // re-export per compatibilità con eventuali import esistenti

  /** Chiavi e util */
  const META_KEY = `${ID}/meta`;
  const elevationLabelsLifecycle = createOptionalRuntimeLifecycle({
    name: "elevation-labels",
    mount: mountElevationLabelWatcher,
    unmount: unmountElevationLabelWatcher,
    cleanupOwnedOutputs: cleanupOwnedElevationLabels,
    reconcileFull: reconcileAllElevationLabels,
  });

  const BASE_URL = (import.meta?.env?.BASE_URL ?? "/"); // es. "/" o "/initiative-tracker/"
  const ORIGIN   = window.location.origin.replace(/\/+$/, "");
  const ASSET    = (name) => `${ORIGIN}${BASE_URL}${name}`.replace(/([^:]\/)\/+/g, "$1");

  // Icone (i file stanno in 'public/', ma si servono dalla root)
  const ICON_ADD    = ASSET("add.svg");
  const ICON_MARK   = ASSET("mark.svg");
  const ICON_REMOVE = ASSET("remove.svg");
  const ICON_BOSS = ASSET("boss.svg");
  const ICON_BOSS_OFF = ASSET("boss-remove.svg");
  const ICON_ELEVATION = ASSET("elevation.svg");
  const ICON_CUSTOM_AURA = ASSET("aoe-circle.svg");
  
  // ===== DEBUG =====
const DEBUG_CTX = false;
const clog = (...a) => { if (DEBUG_CTX) console.debug("[ctx]", ...a); };

// Dump rapido: nome, id, inInitiative, hp/hpMax, attitude
async function dumpItems(ids, label) {
  if (!DEBUG_CTX) return;
  try {
    const idset = new Set(ids);
    const arr = await OBR.scene.items.getItems(i => idset.has(i.id));
    clog(label, arr.map(i => ({
      id: i.id,
      name: i.name,
      inInitiative: !!i.metadata?.[META_KEY]?.inInitiative,
      hp: i.metadata?.[META_KEY]?.hp,
      hpMax: i.metadata?.[META_KEY]?.hpMax,
      att: i.metadata?.[META_KEY]?.attitude,
    })));
  } catch (e) {
    console.warn("[ctx] dumpItems error:", e?.message || e);
  }
}

  /** Evita doppie registrazioni in dev/HMR */
  if (!window.__TBP_CTX_MOUNTED) {
    window.__TBP_CTX_MOUNTED = false;
  }

  /* ----------------------------- Filtri utili ----------------------------- */
  function isCharacter() {
  return { key: "layer", value: "CHARACTER" };
  }
  function hasMeta(op /* "==" | "!=" */) {
  return { key: ["metadata", META_KEY], operator: op, value: undefined };
  }
  function isNotPC() {
  return { key: ["metadata", META_KEY, "attitude"], operator: "!=", value: "pc" };
  }

  /* ----------------------- Altezza submenu (embed) ------------------------ */
  const ROW_H = 28;
  const GAP_Y = 6;
  const PAD_Y = 8;
  const EMBED_3ROWS_H = PAD_Y * 2 + ROW_H * 3 + GAP_Y * 2; // = 124px
  const EMBED_4ROWS_H = PAD_Y * 2 + ROW_H * 4 + GAP_Y * 3; // = 170px circa

  /* --------------------------- Group unificato ---------------------------- */
  const MENU_GROUP = `${ID}/initiative-manage`;
  const CUSTOM_AURA_MODAL_ID = `${ID}/custom-aura-modal`;

  async function customAuraPopoverOptions(tokenIds, { mode = "" } = {}) {
    let viewportWidth = 1200;
    let viewportHeight = 800;
    try { viewportWidth = Number(await OBR.viewport.getWidth()) || viewportWidth; } catch {}
    try { viewportHeight = Number(await OBR.viewport.getHeight()) || viewportHeight; } catch {}
    const isQuickApply = mode === "apply-preset";
    const width = Math.min(isQuickApply ? 460 : 540, Math.max(360, viewportWidth - 32));
    const height = Math.min(isQuickApply ? 480 : 680, Math.max(360, viewportHeight - 96));
    const query = new URLSearchParams();
    for (const tokenId of tokenIds) query.append("tokenId", tokenId);
    if (mode) query.append("mode", mode);

    return {
      id: CUSTOM_AURA_MODAL_ID,
      url: `/custom-aura-modal.html?${query.toString()}`,
      width,
      height,
      anchorReference: "POSITION",
      anchorPosition: {
        left: Math.max(12, viewportWidth - width - 64),
        top: Math.max(12, Math.round((viewportHeight - height) / 2)),
      },
      anchorOrigin: { horizontal: "LEFT", vertical: "TOP" },
      transformOrigin: { horizontal: "LEFT", vertical: "TOP" },
      disableClickAway: true,
      marginThreshold: 12,
      hidePaper: true,
    };
  }

  /* --------------------------- Helper “chiudi” ---------------------------- */
  function closeContextMenuSoon() {
    Promise.resolve().then(() => {
      OBR.player.deselect().catch(() => {});
    });
    setTimeout(() => {
      OBR.player.deselect().catch(() => {});
    }, 20);

  }
  // FIX: usa un filtro per id, non un array
async function toggleLegendaryDefault(itemIds) {
  if (!itemIds?.length) return;

  const idset = new Set(itemIds);
  const items = await OBR.scene.items.getItems(i => idset.has(i.id));

  const allHave = items.length > 0 && items.every(it => !!it.metadata?.[META_KEY]?.legendary);

  if (!allHave) {
    const blocked = items.some(it => {
      const p = it.metadata?.[META_KEY]?.paragon;
      const e = it.metadata?.[META_KEY]?.epic;
      return (p && Number(p.actions) > 1) || !!e;
    });
    if (blocked) {
      console.warn("[legendary] impossibile attivare: token con Paragon/Epic attivo");
      return;
    }
  }

  await OBR.scene.items.updateItems(itemIds, (draft) => {
    for (const it of draft) {
      const m  = it.metadata || {};
      const me = { ...(m[META_KEY] || {}) };
      if (allHave) {
        if (me.legendary) delete me.legendary;
        if (me.legendaryResistances) delete me.legendaryResistances;
      } else {
        me.legendary = { max: 3, current: 3 };
        me.legendaryResistances = {
          max: 3,
          current: 3,
        };
      }
      m[META_KEY] = me;
      it.metadata = m;
    }
  });
}
const paragonToggleExecutor = createParagonToggleExecutor({
  readItems: (ids) => OBR.scene.items.getItems(ids),
  updateItems: (ids, updater) => OBR.scene.items.updateItems(ids, updater),
  readBackItems: (ids) => OBR.scene.items.getItems(ids),
  getRole: async () => {
    try { return await OBR.player.getRole(); } catch { return "PLAYER"; }
  },
  getSceneContext: () => {
    const epoch = currentSceneEpoch();
    return { ready: isCurrentSceneEpoch(epoch), identity: null, epoch };
  },
  isSceneCurrent: (captured) => isCurrentSceneEpoch(captured.epoch),
  patchParagonInits: ({ commandId, disabledIds, scene }) => enqueueInitiativeStateReducer({
    commandId: commandId || nextInitiativeStateCommandId("paragon-cleanup"),
    kind: "paragon-cleanup",
    ownedFields: ["paragonInits"],
    payload: { kind: "paragon-cleanup", disabledIds: [...disabledIds] },
    sceneEpoch: scene.epoch,
    reducer: (previous) => {
      const paragonInits = {
        ...(previous?.paragonInits && typeof previous.paragonInits === "object"
          ? previous.paragonInits
          : {}),
      };
      for (const id of disabledIds) {
        if (Object.hasOwn(paragonInits, id)) delete paragonInits[id];
      }
      return { paragonInits };
    },
  }),
});

async function toggleParagonBossOn(ids, desiredEnabled = null, options = {}) {
  const commandId = options.commandId || nextInitiativeStateCommandId("paragon-toggle");
  const result = await paragonToggleExecutor.enqueue({
    ids,
    desiredEnabled,
    commandId,
  });
  if (result?.status === "blocked") {
    console.warn("[paragon] impossibile attivare: token con Legendary/Epic attive");
  } else if (result?.status === "failed") {
    console.warn("[paragon] comando fallito", result.reason || result.error?.message || "errore sconosciuto");
  } else if (result?.cleanupPending) {
    console.warn("[paragon] token applicato, cleanup state pending");
  }
  return result;
}

async function toggleEpicBossOn(ids) {
  if (!ids?.length) return;

  const idset = new Set(ids);
  const items = await OBR.scene.items.getItems(i => idset.has(i.id));

  const blocked = items.some(it => {
    const me   = it.metadata?.[META_KEY];
    const leg  = me?.legendary && Number(me.legendary.max) > 0;
    const par  = me?.paragon && Number(me.paragon.actions) > 1;
    return leg || par;
  });
  if (blocked) {
    console.warn("[epic] impossibile attivare: token con Legendary/Paragon attivi");
    return;
  }

  await OBR.scene.items.updateItems(ids, (draft) => {
    for (const it of draft) {
      const me = { ...(it.metadata?.[META_KEY] || {}) };
      if (me.epic) { delete me.epic; }
      else { me.epic = { enabled: 1 }; me.initiative = 20; }
      it.metadata = { ...(it.metadata || {}), [META_KEY]: me };
    }
  });
}

  /* ============================ REGISTRAZIONE ============================= */
  export function setupContextMenu() {
    if (window.__TBP_CTX_MOUNTED) return;
    window.__TBP_CTX_MOUNTED = true;

    bindOptionalRuntimeOption({
      service: runtimeOptionsService,
      selector: selectElevationLabelsEnabled,
      lifecycle: elevationLabelsLifecycle,
    });

    /* ======================= “Segna come…” (EMBED) ======================= */
    OBR.contextMenu.create({
      id: `${ID}/mark-as`,
      group: MENU_GROUP, // <— TOP-LEVEL
      icons: [
        {
          icon: ICON_MARK,
          label: "Segna come…",
          filter: {
          every: [
          isCharacter(),
          { key: ["metadata", META_KEY, "inInitiative"], operator: "==", value: true }, // ← SOLO se in iniziativa
          ],
          },
        },
      ],
      embed: {
        url: "/ctx-mark.html",
        height: EMBED_4ROWS_H,
      },
    });

    /* =================== “Rimuovi dall’iniziativa” (CLICK) =================== */
    OBR.contextMenu.create({
      id: `${ID}/remove-from-initiative`,
      group: MENU_GROUP, // <— TOP-LEVEL
      icons: [
        {
          icon: ICON_REMOVE,
          label: "Rimuovi dall’iniziativa",
          filter: {
  every: [
    isCharacter(),
     { key: ["metadata", META_KEY, "inInitiative"], operator: "==", value: true },
        ],
        },
        },
        ],
      /** @param {import("@owlbear-rodeo/sdk").ContextMenuContext} ctx */
      async onClick(ctx) {
        try {
          const ids = Array.isArray(ctx.items)
            ? ctx.items.map(x => typeof x === "string" ? x : x.id)
            : [];
          if (!ids.length) return;

          clog("remove: ctx.items =", ctx.items);
          clog("remove: ids =", ids);

          await dumpItems(ids, "remove: BEFORE");

          await OBR.scene.items.updateItems(ids, (draft) => {
            for (const it of draft) {
              const m  = it.metadata || {};
              const me = { ...(m[META_KEY] || {}) };
              clog("remove:update", it.name, it.id, "had inInitiative=", !!me.inInitiative);
              delete me.inInitiative;                 // << togli SOLO il flag
              m[META_KEY] = me;
              it.metadata = m;
            }
          });

          await dumpItems(ids, "remove: AFTER (immediate)");
          setTimeout(() => { void dumpItems(ids, "remove: AFTER 200ms"); }, 200);
        } catch (err) {
          console.warn("[contextMenu] remove-from-initiative:", err);
        } finally {
          // chiudi menu e deseleziona
          Promise.resolve().then(() => OBR.player.deselect().catch(() => {}));
          setTimeout(() => OBR.player.deselect().catch(() => {}), 20);
        }
      },
    });

    /* ============== “Aggiungi all’iniziativa come…” (EMBED) ============== */
    OBR.contextMenu.create({
      id: `${ID}/add-to-initiative`,
      group: MENU_GROUP, // <— TOP-LEVEL
      icons: [
        {
          icon: ICON_ADD,
          label: "Aggiungi all’iniziativa…",
          filter: {
          every: [
          isCharacter(),
          // Mostra la voce solo se NON è già in iniziativa
          { key: ["metadata", META_KEY, "inInitiative"], operator: "!=", value: true },
          ],
        },
        },
      ],
      embed: {
        url: "/ctx-add.html",
        height: EMBED_4ROWS_H,
      },
    });

    OBR.contextMenu.create({
      id: `${ID}/token-elevation`,
      group: MENU_GROUP,
      icons: [{
        icon: ICON_ELEVATION,
        label: "Imposta quota…",
        filter: {
          roles: ["GM"],
          every: [isCharacter()],
        },
      }],
      embed: {
        url: "/ctx-elevation.html",
        height: 72,
      },
    });

    OBR.contextMenu.create({
      id: `${ID}/custom-aura-manage`,
      group: MENU_GROUP,
      icons: [{
        icon: ICON_CUSTOM_AURA,
        label: "Gestisci aure personalizzate…",
        filter: {
          roles: ["GM"],
          every: [isCharacter()],
        },
      }],
      onClick: async (ctx) => {
        try {
          const tokenIds = [...new Set(
            (Array.isArray(ctx?.items) ? ctx.items : [])
              .map((item) => String(typeof item === "string" ? item : item?.id || "").trim())
              .filter(Boolean),
          )];
          if (!tokenIds.length) return;
          if (tokenIds.length > 1) {
            await OBR.notification.show(
              "Gestisci aure personalizzate richiede un solo token. Per più token usa Applica preset aura…",
              "INFO",
            ).catch(() => {});
            closeContextMenuSoon();
            return;
          }
          await OBR.modal.close(CUSTOM_AURA_MODAL_ID).catch(() => {});
          await OBR.popover.close(CUSTOM_AURA_MODAL_ID).catch(() => {});
          await openTrackedPopover(await customAuraPopoverOptions(tokenIds));
        } catch (error) {
          console.warn("[custom-aura] editor:", error?.message || error);
        }
      },
    });

    OBR.contextMenu.create({
      id: `${ID}/custom-aura-apply-preset`,
      group: MENU_GROUP,
      icons: [{
        icon: ICON_CUSTOM_AURA,
        label: "Applica preset aura…",
        filter: {
          roles: ["GM"],
          every: [isCharacter()],
        },
      }],
      onClick: async (ctx) => {
        try {
          const tokenIds = [...new Set(
            (Array.isArray(ctx?.items) ? ctx.items : [])
              .map((item) => String(typeof item === "string" ? item : item?.id || "").trim())
              .filter(Boolean),
          )];
          if (!tokenIds.length) return;
          await OBR.modal.close(CUSTOM_AURA_MODAL_ID).catch(() => {});
          await OBR.popover.close(CUSTOM_AURA_MODAL_ID).catch(() => {});
          await openTrackedPopover(await customAuraPopoverOptions(tokenIds, { mode: "apply-preset" }));
        } catch (error) {
          console.warn("[custom-aura] preset picker:", error?.message || error);
        }
      },
    });

    // Pulisce le registrazioni legacy, ora gestite dal lister.
    void OBR.contextMenu.remove(`${ID}/spells-embed`).catch(() => {});
    void OBR.contextMenu.remove(`${ID}/remove-condition-embed`).catch(() => {});

  // Abilita Azioni Leggendarie (CLICK)
  OBR.contextMenu.create({
    id: `${ID}/legendary-enable`,
    group: MENU_GROUP,

    icons: [{
      icon: ICON_BOSS,
      label: "Abilita Azioni Leggendarie",
      // Mostra solo su CHARACTER tracciati, senza Paragon, e senza Legendary
      filter: {
        every: [
          isCharacter(),
          hasMeta("!="),
          isNotPC(),
          { key: ["metadata", META_KEY, "paragon"],   operator: "==", value: undefined },
          { key: ["metadata", META_KEY, "legendary"], operator: "==", value: undefined },
          { key: ["metadata", META_KEY, "epic"], operator: "==", value: undefined }
        ],
      },
    }],
    onClick: async (ctx) => {
      try {
        const ids = (ctx.items || []).map(i => i.id);
        if (!ids.length) return;
        await toggleLegendaryDefault(ids); // attiva (default 3) perché nessun selezionato le ha
      } catch (err) {
        console.warn("[contextMenu] legendary-enable:", err);
      } finally {
        closeContextMenuSoon();
      }
    },
  });

  /* ===================== “Disabilita Azioni Leggendarie” (CLICK) ===================== */
  OBR.contextMenu.create({
    id: `${ID}/legendary-disable`,
    group: MENU_GROUP,
    icons: [{
      icon: ICON_BOSS_OFF,
      label: "Disabilita Azioni Leggendarie",
      // Mostra solo su CHARACTER tracciati, senza Paragon, e con Legendary presenti
      filter: {
        every: [
          isCharacter(),
          hasMeta("!="),
          { key: ["metadata", META_KEY, "paragon"],   operator: "==", value: undefined },
          { key: ["metadata", META_KEY, "legendary"], operator: "!=", value: undefined },
          { key: ["metadata", META_KEY, "epic"], operator: "==", value: undefined }
        ],
      },
    }],
    onClick: async (ctx) => {
      try {
        const ids = (ctx.items || []).map(i => i.id);
        if (!ids.length) return;
        await toggleLegendaryDefault(ids); // spegne perché TUTTI le hanno (allHave === true)
      } catch (err) {
        console.warn("[contextMenu] legendary-disable:", err);
      } finally {
        closeContextMenuSoon();
      }
    },
  });

  /* ===================== “Abilita Paragon Boss” (CLICK) ===================== */
  OBR.contextMenu.create({
    id: `${ID}/paragon-enable`,
    group: MENU_GROUP,
    icons: [{
      icon: ICON_BOSS,
      label: "Abilita Paragon Boss",
      // Mostra solo su CHARACTER tracciati, senza Legendary e senza Paragon
      filter: {
        roles: ["GM"],
        every: [
          isCharacter(),
          hasMeta("!="),
          isNotPC(),
          { key: ["metadata", META_KEY, "legendary"], operator: "==", value: undefined },
          { key: ["metadata", META_KEY, "paragon"],   operator: "==", value: undefined },
          { key: ["metadata", META_KEY, "epic"], operator: "==", value: undefined }
        ],
      },
    }],
    onClick: async ({ items }) => {
      try {
        await toggleParagonBossOn(items.map(i => i.id), true); // ON esplicito
      } finally {
        try { await OBR.player.deselect(); } catch {}
      }
    },
  });

  /* ===================== “Disabilita Paragon Boss” (CLICK) ===================== */
  OBR.contextMenu.create({
    id: `${ID}/paragon-disable`,
    group: MENU_GROUP,
    icons: [{
      icon: ICON_BOSS_OFF,
      label: "Disabilita Paragon Boss",
      // Mostra solo su CHARACTER tracciati, senza Legendary e con Paragon presente
      filter: {
        roles: ["GM"],
        every: [
          isCharacter(),
          hasMeta("!="),
          { key: ["metadata", META_KEY, "legendary"], operator: "==", value: undefined },
          { key: ["metadata", META_KEY, "paragon"],   operator: "!=", value: undefined },
          { key: ["metadata", META_KEY, "epic"], operator: "==", value: undefined }
        ],
      },
    }],
    onClick: async ({ items }) => {
      try {
        await toggleParagonBossOn(items.map(i => i.id), false); // OFF esplicito
      } finally {
        try { await OBR.player.deselect(); } catch {}
      }
    },
  });
  /* ===================== “Abilita Epic Boss” (CLICK) ===================== */
OBR.contextMenu.create({
  id: `${ID}/epic-enable`,
  group: MENU_GROUP,
  icons: [{
    icon: ICON_BOSS,
    label: "Abilita Epic Boss",
    // Mostra solo su CHARACTER tracciati, senza Legendary, senza Paragon, senza Epic
    filter: {
      every: [
        isCharacter(),
        hasMeta("!="),
        isNotPC(),
        { key: ["metadata", META_KEY, "legendary"], operator: "==", value: undefined },
        { key: ["metadata", META_KEY, "paragon"],   operator: "==", value: undefined },
        { key: ["metadata", META_KEY, "epic"],      operator: "==", value: undefined },
      ],
    },
  }],
  onClick: async ({ items }) => {
    try { await toggleEpicBossOn(items.map(i => i.id)); } finally {
      try { await OBR.player.deselect(); } catch {}
    }
  },
});

/* ===================== “Disabilita Epic Boss” (CLICK) ===================== */
OBR.contextMenu.create({
  id: `${ID}/epic-disable`,
  group: MENU_GROUP,
  icons: [{
    icon: ICON_BOSS_OFF,
    label: "Disabilita Epic Boss",
    // Mostra solo su CHARACTER tracciati, con Epic presente
    filter: {
      every: [
        isCharacter(),
        hasMeta("!="),
        { key: ["metadata", META_KEY, "epic"], operator: "!=", value: undefined },
      ],
    },
  }],
  onClick: async ({ items }) => {
    try { await toggleEpicBossOn(items.map(i => i.id)); } finally {
      try { await OBR.player.deselect(); } catch {}
    }
  },
});
}

import OBR from "@owlbear-rodeo/sdk";
import { ID } from "./constants.js";
import {
  createMenuMessage,
  readStoredMenuPayload,
} from "./menuPopoverProtocolCore.js";
import { sanitizeQuickActions } from "./quickActionsCore.js";
import { trackerQuickActionSummary } from "./trackerQuickActions.js";

const CHANNEL = `${ID}/tracker-quick-actions`;
const PAYLOAD_PREFIX = `${ID}/tracker-quick-actions/`;
const requestId = new URLSearchParams(window.location.search).get("request") || "";
const shell = document.querySelector("#shell");
const root = document.querySelector("#menu");
let resizeRevision = 0;
let closeOnBlurArmed = false;
let closeRequested = false;
const EXIT_ANIMATION_MS = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches
  ? 0
  : 90;

function send(type, details = {}) {
  void OBR.broadcast.sendMessage(
    CHANNEL,
    createMenuMessage(requestId, type, details),
    { destination: "LOCAL" },
  ).catch(() => {});
}

function revealMenu() {
  requestAnimationFrame(() => shell?.classList.add("is-open"));
}

function sendAfterExit(type, details = {}) {
  if (closeRequested) return;
  closeRequested = true;
  shell?.classList.remove("is-open");
  shell?.classList.add("is-closing");
  window.setTimeout(() => send(type, details), EXIT_ANIMATION_MS);
}

function requestMenuResize() {
  const revision = ++resizeRevision;
  requestAnimationFrame(async () => {
    if (revision !== resizeRevision || !root) return;
    root.style.maxHeight = "none";
    const naturalHeight = Math.ceil(root.scrollHeight + 2);
    let viewportHeight = 800;
    try { viewportHeight = Number(await OBR.viewport.getHeight()) || viewportHeight; } catch {}
    if (revision !== resizeRevision) return;
    const targetHeight = Math.max(88, Math.min(naturalHeight, viewportHeight - 24));
    root.style.maxHeight = `${Math.max(86, targetHeight - 2)}px`;
    root.style.overflowY = naturalHeight > targetHeight ? "auto" : "hidden";
    send("resize", { height: targetHeight });
  });
}

function armClickAwayClose() {
  if (!shell) return;
  shell.tabIndex = -1;
  requestAnimationFrame(() => {
    try {
      window.focus();
      shell.focus({ preventScroll: true });
      closeOnBlurArmed = true;
    } catch {}
  });
}

function render(payload) {
  const actions = sanitizeQuickActions(payload?.actions, { limit: 64 });
  const disabledActionIds = new Set(
    (Array.isArray(payload?.disabledActionIds) ? payload.disabledActionIds : [])
      .map((id) => String(id || "").trim())
      .filter(Boolean),
  );
  root.replaceChildren();
  const title = document.createElement("div");
  title.className = "title";
  title.textContent = payload?.title || "Azioni rapide";
  root.appendChild(title);

  for (const action of actions) {
    const button = document.createElement("button");
    const disabled = disabledActionIds.has(action.id);
    button.type = "button";
    button.setAttribute("role", "menuitem");
    button.disabled = disabled;
    button.setAttribute("aria-disabled", String(disabled));
    button.title = disabled
      ? `${trackerQuickActionSummary(action)} · Già attiva`
      : trackerQuickActionSummary(action);

    const icon = document.createElement("span");
    icon.className = "icon";
    icon.textContent = action.kind === "condition"
      ? "C"
      : action.kind === "feature"
        ? "◆"
        : "✦";
    const copy = document.createElement("span");
    copy.className = "copy";
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = action.label;
    const detail = document.createElement("span");
    detail.className = "detail";
    detail.textContent = trackerQuickActionSummary(action);
    copy.append(label, detail);
    button.append(icon, copy);
    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      sendAfterExit("action", { actionId: action.id });
    });
    root.appendChild(button);
  }
}

const payload = readStoredMenuPayload(localStorage, PAYLOAD_PREFIX, requestId);
if (requestId && payload && sanitizeQuickActions(payload.actions, { limit: 64 }).length) {
  render(payload);
  revealMenu();
  requestMenuResize();
  armClickAwayClose();
  if (document.fonts?.ready) {
    void document.fonts.ready.then(requestMenuResize).catch(() => {});
  }
} else {
  root.textContent = "Azioni rapide non disponibili";
  revealMenu();
  requestMenuResize();
}

window.addEventListener("keydown", (event) => {
  if (event.key === "Escape") sendAfterExit("close");
});
window.addEventListener("blur", () => {
  if (closeOnBlurArmed) sendAfterExit("close");
});

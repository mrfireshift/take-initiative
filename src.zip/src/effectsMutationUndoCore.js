const clone = (value) => {
  if (value === undefined) return undefined;
  if (typeof globalThis.structuredClone === "function") return globalThis.structuredClone(value);
  return JSON.parse(JSON.stringify(value));
};

function canonicalize(value) {
  if (Array.isArray(value)) return value.map(canonicalize);
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(
    Object.keys(value)
      .sort()
      .map((key) => [key, canonicalize(value[key])]),
  );
}

const same = (left, right) => {
  try {
    // OBR metadata is semantically an object tree: SDK normalization can
    // change insertion order without changing the stored effect. Comparing
    // raw JSON would turn that harmless ordering difference into a conflict.
    return JSON.stringify(canonicalize(left)) === JSON.stringify(canonicalize(right));
  } catch {
    return left === right;
  }
};

function snapshot(metadata, field) {
  const present = Object.prototype.hasOwnProperty.call(metadata || {}, field);
  return present ? { present: true, value: clone(metadata[field]) } : { present: false };
}

function snapshotMatches(actual, expected) {
  if (!expected || typeof expected !== "object") return true;
  if (!!actual?.present !== !!expected.present) return false;
  return !actual.present || same(actual.value, expected.value);
}

function legacyEffectField(field, keys) {
  if (field === keys.conditions) return "conditions";
  if (field === keys.spells) return "spells";
  if (field === keys.concentrations) return "concentrations";
  return "";
}

function legacyEffectValue(field, fieldSnapshot, keys, normalizeConditions) {
  const value = fieldSnapshot?.present ? fieldSnapshot.value : undefined;
  if (field === keys.conditions) return normalizeConditions(value || {});
  if (field === keys.spells) return Array.isArray(value) ? clone(value) : [];
  if (field === keys.concentrations) {
    return value && typeof value === "object" ? clone(value) : {};
  }
  return undefined;
}

function coordinatedChanges(entryOrEntries, keys, normalizeConditions) {
  const entries = Array.isArray(entryOrEntries) ? entryOrEntries : [entryOrEntries];
  return entries.flatMap((entry) => {
    if (Array.isArray(entry?.effectsMutation?.changes)) {
      return entry.effectsMutation.changes.map((change) => ({ entry, change }));
    }
    return (Array.isArray(entry?.changes) ? entry.changes : []).map((legacy) => {
      const fields = {};
      const before = {};
      const after = {};
      const metadataFields = {};
      const beforeMetadata = {};
      const afterMetadata = {};
      for (const field of Object.keys(legacy?.before || {})) {
        const effectField = legacyEffectField(field, keys);
        if (effectField) {
          fields[effectField] = true;
          before[effectField] = legacyEffectValue(
            field,
            legacy.before?.[field],
            keys,
            normalizeConditions,
          );
          after[effectField] = legacyEffectValue(
            field,
            legacy.after?.[field],
            keys,
            normalizeConditions,
          );
        } else {
          metadataFields[field] = true;
          beforeMetadata[field] = clone(legacy.before?.[field]);
          afterMetadata[field] = clone(legacy.after?.[field]);
        }
      }
      return {
        entry,
        change: {
          id: legacy?.id,
          fields,
          before,
          after,
          metadataFields,
          beforeMetadata,
          afterMetadata,
          unsupported: !!legacy?.beforePosition
            || !!legacy?.afterPosition
            || Object.prototype.hasOwnProperty.call(legacy || {}, "sceneBefore")
            || Object.prototype.hasOwnProperty.call(legacy || {}, "sceneAfter"),
        },
      };
    });
  });
}

export function buildCoordinatedEffectsUndoPlan({
  currentStates = [],
  sceneItems = [],
  entryOrEntries = [],
  metadataKeys = {},
  normalizeConditions = (value) => Array.isArray(value?.instances) ? clone(value.instances) : [],
} = {}) {
  const keys = {
    conditions: metadataKeys.conditions || "conditions",
    spells: metadataKeys.spells || "spells",
    concentrations: metadataKeys.concentrations || "concentrations",
  };
  const current = new Map(currentStates.map((state) => [state.id, clone(state)]));
  const simulated = new Map([...current].map(([id, state]) => [id, clone(state)]));
  const touched = new Map();
  const metadataTouched = new Map();
  const conflicts = [];

  for (const { entry, change } of coordinatedChanges(entryOrEntries, keys, normalizeConditions)) {
    const id = String(change?.id || "").trim();
    const state = simulated.get(id);
    if (!id || !state) {
      conflicts.push({ entryId: entry?.id || null, itemId: id || null, reason: "missing-item" });
      continue;
    }
    if (change.unsupported) {
      conflicts.push({
        entryId: entry?.id || null,
        itemId: id,
        reason: "unsupported-mixed-legacy-change",
      });
      continue;
    }

    const fields = touched.get(id) || new Set();
    for (const field of ["conditions", "spells", "concentrations"]) {
      if (!change?.fields?.[field]) continue;
      if (!same(state[field], change.after?.[field])) {
        conflicts.push({
          entryId: entry?.id || null,
          itemId: id,
          field,
          reason: "current-value-mismatch",
          expected: clone(change.after?.[field]),
          actual: clone(state[field]),
        });
        continue;
      }
      fields.add(field);
      state[field] = clone(change.before?.[field]);
    }
    touched.set(id, fields);

    const metaFields = metadataTouched.get(id) || new Set();
    for (const field of Object.keys(change?.metadataFields || {})) {
      if (!change.metadataFields[field]) continue;
      const actual = snapshot(state.metadata, field);
      const expected = change.afterMetadata?.[field];

      if (field === "classFeatureState" && expected?.present && change.beforeMetadata?.[field]?.present) {
        const beforeVal = change.beforeMetadata[field].value || {};
        const afterVal = expected.value || {};
        const actualVal = actual.present ? actual.value || {} : {};

        const beforeRes = beforeVal.resources || {};
        const afterRes = afterVal.resources || {};
        const allPoolIds = new Set([...Object.keys(beforeRes), ...Object.keys(afterRes)]);
        const touchedPoolIds = [...allPoolIds].filter((poolId) => !same(beforeRes[poolId], afterRes[poolId]));

        const beforeInstList = Array.isArray(beforeVal.instances) ? beforeVal.instances : [];
        const afterInstList = Array.isArray(afterVal.instances) ? afterVal.instances : [];
        const beforeInstMap = new Map(beforeInstList.map((i) => [String(i?.instanceId || "").trim(), i]));
        const afterInstMap = new Map(afterInstList.map((i) => [String(i?.instanceId || "").trim(), i]));
        const allInstIds = new Set([...beforeInstMap.keys(), ...afterInstMap.keys()]);
        allInstIds.delete("");
        const touchedInstIds = [...allInstIds].filter((instId) => !same(beforeInstMap.get(instId), afterInstMap.get(instId)));

        if (touchedPoolIds.length > 0 || touchedInstIds.length > 0) {
          const actualRes = actualVal.resources || {};
          const actualInstList = Array.isArray(actualVal.instances) ? actualVal.instances : [];
          const actualInstMap = new Map(actualInstList.map((i) => [String(i?.instanceId || "").trim(), i]));

          let hasConflict = false;
          for (const poolId of touchedPoolIds) {
            if (!same(actualRes[poolId], afterRes[poolId])) {
              conflicts.push({
                entryId: entry?.id || null,
                itemId: id,
                field,
                poolId,
                reason: "current-value-mismatch",
                expected: clone(afterRes[poolId]),
                actual: clone(actualRes[poolId]),
              });
              hasConflict = true;
            }
          }
          for (const instId of touchedInstIds) {
            if (!same(actualInstMap.get(instId), afterInstMap.get(instId))) {
              conflicts.push({
                entryId: entry?.id || null,
                itemId: id,
                field,
                instanceId: instId,
                reason: "current-value-mismatch",
                expected: clone(afterInstMap.get(instId)),
                actual: clone(actualInstMap.get(instId)),
              });
              hasConflict = true;
            }
          }

          if (!hasConflict) {
            metaFields.add(field);
            const nextState = clone(actualVal);
            nextState.resources ||= {};
            for (const poolId of touchedPoolIds) {
              if (Object.prototype.hasOwnProperty.call(beforeRes, poolId)) {
                nextState.resources[poolId] = clone(beforeRes[poolId]);
              } else {
                delete nextState.resources[poolId];
              }
            }
            let nextInstances = clone(actualInstList);
            for (const instId of touchedInstIds) {
              if (beforeInstMap.has(instId)) {
                const idx = nextInstances.findIndex((i) => String(i?.instanceId || "").trim() === instId);
                if (idx >= 0) nextInstances[idx] = clone(beforeInstMap.get(instId));
                else nextInstances.push(clone(beforeInstMap.get(instId)));
              } else {
                nextInstances = nextInstances.filter((i) => String(i?.instanceId || "").trim() !== instId);
              }
            }
            nextState.instances = nextInstances;
            state.metadata[field] = nextState;
          }
          continue;
        }
      }

      if (!snapshotMatches(actual, expected)) {
        conflicts.push({
          entryId: entry?.id || null,
          itemId: id,
          field,
          reason: "current-value-mismatch",
          expected: clone(expected),
          actual: clone(actual),
        });
        continue;
      }
      metaFields.add(field);
      const restored = clone(change.beforeMetadata?.[field] || { present: false });
      if (restored.present) state.metadata[field] = restored.value;
      else delete state.metadata[field];
    }
    metadataTouched.set(id, metaFields);
  }

  const undoSideEffects = (Array.isArray(entryOrEntries) ? entryOrEntries : [entryOrEntries])
    .flatMap((entry) => Array.isArray(entry?.effectsMutation?.sideEffects)
      ? entry.effectsMutation.sideEffects
      : [])
    .map((change) => change?.type === "metadata"
      ? {
        id: change?.id,
        type: "metadata",
        metadataKey: String(change?.metadataKey || ""),
        restore: clone(change?.before || { present: false }),
        expected: clone(change?.after || { present: false }),
      }
      : change?.type === "static-zone-move"
        ? {
          id: change?.id,
          type: "static-zone-move",
          metadataKey: String(change?.metadataKey || ""),
          restorePosition: clone(change?.beforePosition || null),
          expectedPosition: clone(change?.afterPosition || null),
          restoreMetadata: clone(change?.beforeMetadata || { present: false }),
          instanceId: String(change?.instanceId || ""),
          ruleId: String(change?.ruleId || ""),
        }
      : (change?.type === "token:teleport" || change?.type === "token-position")
        ? {
          id: change?.id,
          type: "token:teleport",
          restorePosition: clone(change?.beforePosition ?? change?.before?.position ?? null),
          expectedPosition: clone(change?.afterPosition ?? change?.after?.position ?? null),
        }
      : {
        id: change?.id,
        type: "item",
        restore: clone(change?.before ?? null),
        expected: clone(change?.after ?? null),
      });
  const sceneById = new Map(sceneItems.map((item) => [item.id, item]));
  for (const sideEffect of undoSideEffects) {
    const actual = sceneById.get(sideEffect.id) || null;
    let matches = false;
    let conflictField = null;
    let conflictReason = "scene-side-effect-mismatch";

    if (sideEffect.type === "metadata") {
      matches = !!actual && snapshotMatches(snapshot(actual.metadata, sideEffect.metadataKey), sideEffect.expected);
      conflictField = sideEffect.metadataKey;
    } else if (sideEffect.type === "static-zone-move") {
      matches = !!actual
        && same(actual.position, sideEffect.expectedPosition)
        && String(actual.metadata?.[sideEffect.metadataKey]?.instanceId || "") === sideEffect.instanceId
        && String(actual.metadata?.[sideEffect.metadataKey]?.ruleId || "") === sideEffect.ruleId;
    } else if (sideEffect.type === "token:teleport" || sideEffect.type === "token-position") {
      matches = !!actual && same(actual.position, sideEffect.expectedPosition);
      conflictField = "position";
      if (!actual) conflictReason = "token-teleport-target-missing";
    } else {
      matches = sideEffect.expected === null ? actual === null : same(actual, sideEffect.expected);
    }

    if (!matches) {
      conflicts.push({
        itemId: sideEffect.id || null,
        field: conflictField,
        reason: conflictReason,
      });
    }
  }

  if (conflicts.length) return { status: "conflict", conflicts };

  const changes = [];
  for (const id of new Set([...touched.keys(), ...metadataTouched.keys()])) {
    const fields = touched.get(id) || new Set();
    const metaFields = metadataTouched.get(id) || new Set();
    const beforeState = current.get(id);
    const afterState = simulated.get(id);
    const change = {
      id,
      fields: Object.fromEntries([...fields].map((field) => [field, true])),
      before: Object.fromEntries([...fields].map((field) => [field, clone(beforeState[field])])),
      after: Object.fromEntries([...fields].map((field) => [field, clone(afterState[field])])),
    };
    if (metaFields.size) {
      change.metadataFields = Object.fromEntries([...metaFields].map((field) => [field, true]));
      change.beforeMetadata = Object.fromEntries([...metaFields].map((field) => [
        field,
        snapshot(beforeState.metadata, field),
      ]));
      change.afterMetadata = Object.fromEntries([...metaFields].map((field) => [
        field,
        snapshot(afterState.metadata, field),
      ]));
    }
    changes.push(change);
  }
  return {
    operations: [],
    changes,
    changedIds: changes.map((change) => change.id),
    undoSideEffects,
    states: changes.map((change) => ({ id: change.id, ...clone(simulated.get(change.id)) })),
    conflicts,
  };
}

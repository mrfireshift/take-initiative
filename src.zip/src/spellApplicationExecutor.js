import OBR from "@owlbear-rodeo/sdk";
import { ID } from "./constants.js";
import { createSpellInstanceId } from "./spells.js";
import { getConditionInstances, refreshConditionLabels } from "./conditions.js";
import {
  spellEffectConditionName,
  spellEffectConditionOptions,
} from "./spellEffectCore.js";
import {
  requireAppliedEffectsMutation,
  runEffectsMutation,
} from "./effectsMutations.js";
import {
  buildSpellApplicationIntent,
  buildSpellApplicationPlan,
} from "./spellApplicationPlanCore.js";
import { buildSpellActiveActionPlan } from "./spellActiveActionCore.js";
import {
  buildSpellActiveResolutionFailureOperations,
  buildSpellActiveResolutionSuccessOperations,
  buildSpellActiveResolutionPostDamageOperations,
  buildSpellActiveResolutionLinkedEffectRemovals,
  buildSpellActiveResolutionResourceOperations,
  normalizeActiveResolutionTargetIds,
  resolveSpellActiveResolutionDamage,
  resolveSpellActiveResolutionHealing,
  isPrismaticWallActiveResolutionKind,
  validateSpellActiveResolutionPayload,
} from "./spellActiveResolutionCore.js";
import { validateSpellActiveResolutionCommit } from "./spellActiveResolutionValidation.js";
import {
  calculateQuickHPChange,
  QUICK_HP_FACTORS,
  QUICK_HP_MODES,
} from "./quickHpCore.js";
import { spellCasterHealingChange } from "./spellDamageHealingCore.js";
import {
  resolveZeroHPUnconsciousAction,
  resolveDamageEndsConditionRemovals,
  ZERO_HP_UNCONSCIOUS_TYPE,
} from "./hpConditionRulesCore.js";
import { currentInitiativeTurnKey } from "./turnBoundaryCore.js";
import { emitMatchedSpellVisual } from "./embersMatchedVisualRenderer.js";
import {
  requestSpellAreaPlacement,
  requestSpellZoneMovement,
} from "./spellAreaPlacementClient.js";
import {
  createSpellBoardTokenId,
  getSpellBoardTokenRule,
} from "./spellBoardTokenCore.js";
import {
  buildStaticSpellChildZoneItem,
  requestStaticSpellZoneReconcile,
} from "./spellStaticZone.js";
import { SPELL_STATIC_ZONE_META_KEY, translatedZoneArea } from "./spellStaticZoneCore.js";
import { planWallOfLightShortening } from "./wallOfLightActiveCore.js";
import {
  PRISMATIC_WALL_SPELL_ID,
  prismaticWallLayerManagementPlan,
  prismaticWallStateFromCastContext,
  prismaticWallSpellUpsertOperation,
  prismaticWallTraversalMarker,
  prismaticWallTraversalPlan,
} from "./prismaticWallRules.js";
import {
  attachSpellExecutionHistory,
} from "./spellExecutionHistoryCore.js";
import { buildSpellCausality } from "./combatLogCausalityCore.js";

const STATE_KEY = `${ID}/state`;

const uniqueIds = (values = []) => Array.from(new Set(
  (Array.isArray(values) ? values : [])
    .map((value) => String(value || "").trim())
    .filter(Boolean),
));

export async function executeSpellZoneMovement({
  group = null,
  action = null,
  casterName = "",
  movementChoice = "",
  sceneEpoch = null,
  sceneIdentity = null,
  commandId = "",
  isCurrent = null,
  carriedItemIds = [],
} = {}) {
  const ruleId = String(action?.ruleId || "").trim();
  const instanceId = String(group?.instanceId || action?.instanceId || "").trim();
  const zoneItemId = String(action?.zoneItemId || "").trim();
  const casterId = String(group?.casterId || "").trim();
  if (!ruleId || !instanceId || !zoneItemId || !casterId) {
    throw new Error("Invalid spell zone movement: context-required");
  }
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-zone-movement");
  }
  const result = await requestSpellZoneMovement({
    ruleId,
    casterId,
    instanceId,
    zoneItemId,
    movementChoice,
  }, {
    broadcast: OBR.broadcast,
    windowRef: globalThis.window,
  });
  if (result?.status !== "confirmed" || !result?.preview) {
    if (result?.status === "cancelled") return [];
    throw new Error(
      String(result?.error || "Il movimento della zona non è stato confermato."),
    );
  }
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-zone-mutation");
  }
  const preview = result.preview;
  const carriedIds = uniqueIds([
    ...(Array.isArray(carriedItemIds) ? carriedItemIds : []),
    ...(Array.isArray(action?.carriedItemIds) ? action.carriedItemIds : []),
  ]);
  const movement = await runEffectsMutation([], {
    kind: "spell-zone-move",
    label: `Sposta zona: ${String(group?.name || "Incantesimo").trim()}`,
    targetIds: [casterId],
    sideEffects: [{
      type: "static-zone:move",
      zoneItemId,
      instanceId,
      ruleId,
      casterId,
      initialPosition: preview.initialPosition,
      proposedPosition: preview.proposedPosition,
      ...(preview.contactTargetId
        ? { contactTargetId: String(preview.contactTargetId).trim() }
        : {}),
      ...(preview.movementChoice
        ? { movementChoice: String(preview.movementChoice).trim() }
        : {}),
      ...(carriedIds.length ? { carriedItemIds: carriedIds } : {}),
    }],
    history: {
      kind: "spell-zone-move",
      label: `Sposta zona: ${String(group?.name || casterName || "Incantesimo").trim()}`,
      payload: {
        instanceId,
        zoneItemId,
        ruleId,
        causality: buildSpellCausality({
          eventType: "zone-move",
          spellId: group?.spellId,
          spellName: group?.name,
          instanceId,
          casterId,
          casterName: casterName || group?.casterName,
          phase: group?.castContext?.phase,
          targetIds: preview?.contactTargetId ? [preview.contactTargetId] : [],
          zone: {
            action: "move",
            zoneItemId,
            ruleId,
            movementChoice: preview?.movementChoice || movementChoice,
          },
        }),
      },
    },
    ...(sceneIdentity ? { sceneIdentity } : {}),
    ...(commandId ? { commandId } : {}),
  });
  requireAppliedEffectsMutation(movement);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory(movement.changedIds || [], {
      ...movement,
      stale: true,
      postCommitPending: true,
    });
  }
  return attachSpellExecutionHistory(movement.changedIds || [], movement);
}

export async function executeSpellZoneDirection({
  group = null,
  action = null,
  casterName = "",
  sceneEpoch = null,
  sceneIdentity = null,
  commandId = "",
  isCurrent = null,
} = {}) {
  const ruleId = String(action?.ruleId || "").trim();
  const instanceId = String(group?.instanceId || action?.instanceId || "").trim();
  const zoneItemId = String(action?.zoneItemId || "").trim();
  const casterId = String(group?.casterId || "").trim();
  if (!ruleId || !instanceId || !zoneItemId || !casterId) {
    throw new Error("Invalid spell zone direction: context-required");
  }
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-zone-direction");
  }
  const result = await requestSpellAreaPlacement({
    ruleId,
    casterId,
    context: {
      instanceId,
      zoneItemId,
      directionChange: true,
    },
  }, {
    broadcast: OBR.broadcast,
    windowRef: globalThis.window,
  });
  if (result?.status !== "confirmed" || !result?.preview) {
    if (result?.status === "cancelled") return [];
    throw new Error(
      String(result?.error || "La nuova direzione della zona non è stata confermata."),
    );
  }
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-zone-mutation");
  }
  const preview = result.preview;
  const direction = await runEffectsMutation([], {
    kind: "spell-zone-direction",
    label: `Cambia direzione: ${String(group?.name || "Incantesimo").trim()}`,
    targetIds: [casterId],
    sideEffects: [{
      type: "static-zone:reorient",
      zoneItemId,
      instanceId,
      ruleId,
      casterId,
      preview,
    }],
    history: {
      kind: "spell-zone-direction",
      label: `Cambia direzione: ${String(group?.name || casterName || "Incantesimo").trim()}`,
      payload: {
        instanceId,
        zoneItemId,
        ruleId,
        causality: buildSpellCausality({
          eventType: "zone-reorient",
          spellId: group?.spellId,
          spellName: group?.name,
          instanceId,
          casterId,
          casterName: casterName || group?.casterName,
          phase: group?.castContext?.phase,
          zone: { action: "reorient", zoneItemId, ruleId },
        }),
      },
    },
    ...(sceneIdentity ? { sceneIdentity } : {}),
    ...(commandId ? { commandId } : {}),
  });
  requireAppliedEffectsMutation(direction);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory(direction.changedIds || [], {
      ...direction,
      stale: true,
      postCommitPending: true,
    });
  }
  return attachSpellExecutionHistory(direction.changedIds || [], direction);
}

export async function getCurrentSpellAppliedAt() {
  try {
    const metadata = await OBR.scene.getMetadata();
    const state = metadata?.[STATE_KEY] || {};
    const order = Array.isArray(state.order) ? state.order : [];
    return {
      round: Math.max(1, Number(state.round || 1)),
      actorId: order[state.current] || null,
      phase: "turn",
      turnKey: currentInitiativeTurnKey(state),
    };
  } catch {
    return null;
  }
}

export async function executeSpellActiveAction({
  spell = null,
  actionId = "",
  group = null,
  selectedTargetIds = [],
  appliedAt = undefined,
  casterName = "",
  sceneEpoch = null,
  sceneIdentity = null,
  commandId = "",
  isCurrent = null,
  ignoreTargetLimit = false,
} = {}) {
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-active-action");
  }
  const resolvedAppliedAt = appliedAt === undefined
    ? await getCurrentSpellAppliedAt()
    : appliedAt;
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-active-action");
  }
  const actionPlan = buildSpellActiveActionPlan({
    spell,
    actionId,
    group,
    selectedTargetIds,
    appliedAt: resolvedAppliedAt,
    casterName,
    ignoreTargetLimit,
  });
  if (!actionPlan.valid) {
    throw new Error("Invalid active spell action: " + actionPlan.errors.join(", "));
  }

  const sideEffects = [];
  if (actionPlan.zoneRuleChoice) {
    sideEffects.push({
      type: "static-zone:set-rule-choice",
      selector: { instanceId: group?.instanceId || "" },
      ruleChoice: actionPlan.zoneRuleChoice,
      requireMatch: true,
    });
    if (actionPlan.action?.clearChildZones === true) {
      sideEffects.push({
        type: "static-zone:child-zones",
        parentZoneId: String(group?.zoneItemId || "").trim(),
        parentInstanceId: String(group?.instanceId || "").trim(),
        casterId: String(group?.casterId || "").trim(),
        removeAllChildren: true,
        items: [],
      });
    }
  }
  if (actionPlan.entityAction) {
    sideEffects.push({
      type: "spell-board-token:update-state",
      instanceId: String(group?.instanceId || "").trim(),
      action: actionPlan.entityAction,
      targetIds: actionPlan.subjectIds,
    });
  }
  const mutation = await runEffectsMutation(actionPlan.operations, {
    kind: "spell",
    label: actionPlan.historyLabel,
    targetIds: [String(group?.casterId || "").trim(), ...selectedTargetIds].filter(Boolean),
    sideEffects,
    history: {
      kind: "spell",
      label: actionPlan.historyLabel,
      payload: {
        causality: buildSpellCausality({
          eventType: "active-action",
          spellId: spell?.id || group?.spellId,
          spellName: spell?.displayName || spell?.name || group?.name,
          instanceId: group?.instanceId,
          slotLevel: group?.castContext?.slotLevel,
          phase: group?.castContext?.phase,
          casterId: group?.casterId,
          casterName: casterName || group?.casterName,
          targets: group?.targets,
          targetIds: actionPlan.subjectIds,
          action: actionPlan.action,
          concentrationAction: actionPlan.action?.concentrationAction,
          concentrationInstanceId: group?.instanceId,
        }),
      },
    },
    ...(sceneIdentity ? { sceneIdentity } : {}),
    ...(commandId ? { commandId } : {}),
  });
  requireAppliedEffectsMutation(mutation);
  const changedIds = mutation.changedIds;
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory(changedIds, {
      ...mutation,
      stale: true,
      postCommitPending: true,
    });
  }
  if (actionPlan.zoneRuleChoice) {
    // Il cambio di variante è una scrittura della zona persistente: completa
    // subito la stessa pipeline static-zone, anche quando l'azione arriva dal
    // popup di turno (il suo overview può non esporre zoneItemId).
    await requestStaticSpellZoneReconcile({
      reason: "active-action",
      force: true,
      immediate: true,
    });
    if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
      return attachSpellExecutionHistory(changedIds, {
        ...mutation,
        stale: true,
        postCommitPending: true,
      });
    }
  }
  await refreshConditionLabels(changedIds);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory(changedIds, {
      ...mutation,
      stale: true,
      postCommitPending: true,
    });
  }
  return attachSpellExecutionHistory(changedIds, mutation);
}

function metadataSnapshot(meta, field) {
  return Object.prototype.hasOwnProperty.call(meta || {}, field)
    ? { present: true, value: meta[field] }
    : { present: false };
}

function manualDamageValue(value) {
  const raw = value && typeof value === "object"
    ? value.amount ?? value.total ?? value.damage ?? value.value
    : value;
  if (raw === undefined || raw === null || String(raw).trim() === "") return null;
  const parsed = Number(raw);
  return Number.isFinite(parsed) && parsed >= 0 ? Math.floor(parsed) : null;
}

function banishmentThresholdTargetIds({ spell, phasePlan, damageTargets = [] } = {}) {
  if (spell?.id !== "phb2014-punizione-esiliante") return null;
  const threshold = Number(phasePlan?.resolution?.mechanics?.banishmentThresholdHp);
  if (!Number.isFinite(threshold)) return null;
  return Array.from(new Set((Array.isArray(damageTargets) ? damageTargets : [])
    .filter((target) => Number(target?.afterHP) <= threshold
      && Number(target?.afterHP) < Number(target?.beforeHP))
    .map((target) => String(target?.id || "").trim())
    .filter(Boolean)));
}

function scopeBanishmentOperations(operations, eligibleTargetIds) {
  if (!Array.isArray(operations) || eligibleTargetIds === null) return operations;
  const eligible = new Set(eligibleTargetIds);
  return operations.flatMap((operation) => {
    if (!operation || typeof operation !== "object") return [];
    if (operation.type === "condition:add") {
      const targetIds = (Array.isArray(operation.targetIds) ? operation.targetIds : [])
        .filter((targetId) => eligible.has(String(targetId || "").trim()));
      return targetIds.length ? [{ ...operation, targetIds }] : [];
    }
    if (operation.type === "condition:automate") {
      const subjectIds = (Array.isArray(operation.subjectIds) ? operation.subjectIds : [])
        .filter((targetId) => eligible.has(String(targetId || "").trim()));
      return subjectIds.length ? [{ ...operation, subjectIds }] : [];
    }
    if (operation.type === "spell:upsert" || operation.type === "concentration:register") {
      return eligible.size ? [operation] : [];
    }
    return [operation];
  });
}

function spellApplicationNoop(status, reason, extra = {}) {
  const result = [];
  Object.defineProperties(result, {
    status: { value: status, enumerable: false, configurable: true },
    reason: { value: reason, enumerable: false, configurable: true },
    changedIds: { value: [], enumerable: false, configurable: true },
    ...Object.fromEntries(Object.entries(extra).map(([key, value]) => [key, {
      value,
      enumerable: false,
      configurable: true,
    }])),
  });
  return result;
}

async function preparedInstanceIsCurrent(casterId, activeConcentration, spellId) {
  const instanceId = String(activeConcentration?.instanceId || "").trim();
  const caster = String(casterId || "").trim();
  if (!instanceId || !caster) return true;
  const [item] = await OBR.scene.items.getItems([caster]);
  const meta = item?.metadata?.[`${ID}/meta`] || {};
  const spells = Array.isArray(meta[`${ID}/spells`]) ? meta[`${ID}/spells`] : [];
  return spells.some((entry) => (
    String(entry?.instanceId || "").trim() === instanceId
    && (!spellId || String(entry?.spellId || "").trim() === String(spellId).trim())
    && String(entry?.castContext?.phase || "").trim() === "prepare"
  ));
}

async function buildPreparedInitialDamageMutation({
  targetIds = [],
  amount = null,
} = {}) {
  const damage = manualDamageValue(amount);
  if (damage === null || damage <= 0) {
    return { metadataPatches: [], operations: [], applied: 0, targets: [] };
  }
  const ids = Array.from(new Set((targetIds || []).filter(Boolean)));
  const items = await OBR.scene.items.getItems(ids);
  const byId = new Map(items.map((item) => [item.id, item]));
  const metadataPatches = [];
  const operations = [];
  const unconsciousIds = [];
  const unconsciousRemovals = [];
  const targets = [];
  const currentHpById = new Map();

  for (const targetId of ids) {
    const item = byId.get(targetId);
    const meta = item?.metadata?.[`${ID}/meta`] || {};
    if (
      !item
      || !Object.prototype.hasOwnProperty.call(meta, "hp")
      || !Object.prototype.hasOwnProperty.call(meta, "hpMax")
    ) {
      throw new Error("spell-initial-damage-hp-required");
    }
    const currentHp = currentHpById.has(targetId)
      ? currentHpById.get(targetId)
      : meta.hp;
    const hpChange = calculateQuickHPChange({
      mode: QUICK_HP_MODES.DAMAGE,
      value: damage,
      factor: QUICK_HP_FACTORS.FULL,
      hp: currentHp,
      hpMax: meta.hpMax,
    });
    currentHpById.set(targetId, hpChange.afterHP);
    targets.push({
      id: targetId,
      name: item.name,
      requestedDamage: damage,
      appliedDamage: Math.max(0, Number(currentHp) - Number(hpChange.afterHP)),
      beforeHP: currentHp,
      afterHP: hpChange.afterHP,
    });
    if (!hpChange.changed) continue;
    metadataPatches.push({
      id: targetId,
      fields: {
        hp: {
          expected: metadataSnapshot(meta, "hp"),
          value: hpChange.afterHP,
        },
        hpMax: {
          expected: metadataSnapshot(meta, "hpMax"),
          value: hpChange.hpMax,
        },
      },
    });
    const zeroAction = resolveZeroHPUnconsciousAction({
      ...meta,
      hp: hpChange.afterHP,
      hpMax: hpChange.hpMax,
    }, getConditionInstances(meta.conditions || {}));
    if (zeroAction.add) unconsciousIds.push(targetId);
    unconsciousRemovals.push(...zeroAction.removeInstanceIds.map((instanceId) => ({
      itemId: targetId,
      instanceId,
    })));
    if (hpChange.afterHP < Number(currentHp)) {
      for (const instanceId of resolveDamageEndsConditionRemovals(
        getConditionInstances(meta.conditions || {}),
      )) {
        unconsciousRemovals.push({ itemId: targetId, instanceId });
      }
    }
  }

  if (unconsciousIds.length) {
    operations.push({
      type: "condition:add",
      targetIds: Array.from(new Set(unconsciousIds)),
      conditionName: "Privo di sensi",
      options: { type: ZERO_HP_UNCONSCIOUS_TYPE, expiry: { mode: "manual" } },
    }, {
      type: "condition:automate",
      subjectIds: Array.from(new Set(unconsciousIds)),
    });
  }
  if (unconsciousRemovals.length) {
    operations.push({ type: "condition:remove-instances", removals: unconsciousRemovals });
  }
  return {
    metadataPatches,
    operations,
    applied: damage,
    targets,
  };
}

function activeResolutionAction(payload) {
  return payload?.action && typeof payload.action === "object"
    ? payload.action
    : null;
}

function cloneValue(value) {
  if (value === undefined) return undefined;
  if (typeof globalThis.structuredClone === "function") return globalThis.structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function prismaticWallSpellEntry(item, payload) {
  const spells = item?.metadata?.[`${ID}/meta`]?.[`${ID}/spells`];
  return (Array.isArray(spells) ? spells : []).find((entry) => (
    String(entry?.instanceId || "").trim() === String(payload?.instanceId || "").trim()
    && String(entry?.spellId || "").trim() === PRISMATIC_WALL_SPELL_ID
    && String(entry?.casterId || payload?.casterId || "").trim() === String(payload?.casterId || "").trim()
  )) || null;
}

function hasActiveEffect(item, effectId) {
  const wanted = String(effectId || "").trim();
  if (!wanted) return false;
  return getConditionInstances(item?.metadata?.[`${ID}/meta`]?.conditions)
    .some((instance) => (
      instance?.active !== false
      && String(instance?.effectId || "").trim() === wanted
    ));
}

function activeResolutionOutcome(payload, targetId, attackOutcome) {
  return payload?.action?.resolutionKind === "single-attack"
    ? String(attackOutcome || "").trim()
    : String(payload?.outcomes?.[targetId] || "").trim();
}

function childPlacementEntries(placement) {
  if (Array.isArray(placement?.children)) return placement.children.filter(Boolean);
  return placement?.start && placement?.end ? [placement] : [];
}

export async function executeSpellActiveResolution({
  payload = null,
  placement = null,
  targetIds = [],
  outcomes = {},
  layerOutcomes = {},
  layerDamage = {},
  layerId = "",
  traversalId = "",
  damageRoll = 0,
  attackOutcome = "",
  saveAbility = "",
  attacks = [],
  shorteningFrom = "",
  naturalStormBonus = false,
  sceneEpoch = null,
  sceneIdentity = null,
  commandId = "",
  isCurrent = null,
} = {}) {
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-active-resolution");
  }
  const normalizedPayload = {
    ...(payload && typeof payload === "object" ? payload : {}),
    ...(outcomes && typeof outcomes === "object" ? { outcomes } : {}),
  };
  const payloadValidation = validateSpellActiveResolutionPayload(payload);
  if (!payloadValidation.valid) {
    throw new Error("Invalid active spell resolution: " + payloadValidation.errors.join(", "));
  }
  const attackEntries = (Array.isArray(attacks) ? attacks : [])
    .map((entry) => ({
      targetId: String(entry?.targetId || entry?.id || "").trim(),
      attackOutcome: String(entry?.attackOutcome || entry?.outcome || "").trim(),
      damageRoll: entry?.damageRoll ?? entry?.damage ?? 0,
    }))
    .filter((entry) => entry.targetId);
  const ids = normalizeActiveResolutionTargetIds([
    ...targetIds,
    ...attackEntries.map((entry) => entry.targetId),
  ]);
  const prismaticWallResolution = isPrismaticWallActiveResolutionKind(payload?.action);
  if (!ids.length
    && payload?.action?.resolutionKind !== "child-zone"
    && payload?.action?.allowEmptyTargets !== true
    && payload?.action?.resolutionKind !== "prismatic-wall-layers") {
    throw new Error("active-resolution-targets-required");
  }
  const commitInput = {
    payload: normalizedPayload,
    placement,
    targetIds: ids,
    outcomes,
    layerOutcomes,
    layerDamage,
    layerId,
    traversalId,
    damageRoll,
    attackOutcome,
    saveAbility,
    attacks: attackEntries,
    shorteningFrom,
  };
  const preflight = await validateSpellActiveResolutionCommit(commitInput);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-active-resolution");
  }
  if (!preflight.valid) {
    throw new Error("Invalid active spell resolution: " + preflight.errors.join(", "));
  }

  const itemIds = prismaticWallResolution
    ? normalizeActiveResolutionTargetIds([payload.casterId, ...ids])
    : ids;
  const items = await OBR.scene.items.getItems(itemIds);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-active-resolution");
  }
  const byId = new Map(items.map((item) => [item.id, item]));
  const metadataPatches = [];
  const operations = [];
  const unconsciousIds = [];
  const unconsciousRemovals = [];
  const resolutionDamageByTarget = new Map();
  const resolutionHealingByTarget = new Map();
  const action = activeResolutionAction(payload);
  let staticZoneShortening = null;
  if (!prismaticWallResolution && action?.shortenStaticZone && payload?.zoneItemId) {
    const [[zoneItem], scale] = await Promise.all([
      OBR.scene.items.getItems([payload.zoneItemId]),
      OBR.scene.grid.getScale().catch(() => ({ parsed: { multiplier: 1.5, unit: "m" } })),
    ]);
    if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
      throw new Error("scene-epoch-stale-before-active-resolution");
    }
    const zoneMetadata = zoneItem?.metadata?.[SPELL_STATIC_ZONE_META_KEY];
    if (
      !zoneItem
      || zoneMetadata?.role !== "root"
      || String(zoneMetadata.instanceId || "") !== String(payload.instanceId || "")
      || String(zoneMetadata.casterId || "") !== String(payload.casterId || "")
    ) {
      throw new Error("active-resolution-zone-shortening-context-invalid");
    }
    const configuredFrom = String(action.shortenStaticZone.from || "end").trim();
    const requestedFrom = String(shorteningFrom || "").trim();
    const shorteningSide = action.shortenStaticZone.chooseFrom === true
      && ["start", "end"].includes(requestedFrom)
      ? requestedFrom
      : configuredFrom;
    const shortening = planWallOfLightShortening({
      zoneItem,
      scale: scale?.parsed || scale,
      meters: action.shortenStaticZone.meters,
      from: shorteningSide,
    });
    if (!shortening.valid) {
      throw new Error(
        `active-resolution-zone-shortening-invalid: ${(shortening.errors || []).join(", ")}`,
      );
    }
    staticZoneShortening = {
      ...shortening,
      ruleId: String(zoneMetadata.ruleId || ""),
    };
    if (shortening.endsSpell && action.shortenStaticZone.endSpellAtZero === true) {
      operations.push(
        {
          type: "concentration:break",
          casterIds: [payload.casterId],
          reference: payload.instanceId,
        },
        {
          type: "spell:remove-instance",
          targetIds: [payload.casterId],
          instanceId: payload.instanceId,
        },
      );
    }
  }
  if (!prismaticWallResolution && action?.resource) {
    const [casterItem] = await OBR.scene.items.getItems([payload.casterId]);
    if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
      throw new Error("scene-epoch-stale-before-active-resolution");
    }
    const casterMeta = casterItem?.metadata?.[`${ID}/meta`] || {};
    const casterSpells = Array.isArray(casterMeta[`${ID}/spells`]) ? casterMeta[`${ID}/spells`] : [];
    const spellEntry = casterSpells.find((entry) => (
      String(entry?.instanceId || "").trim() === String(payload.instanceId || "").trim()
    ));
    const resourcePlan = buildSpellActiveResolutionResourceOperations({
      action,
      payload,
      spellEntry,
    });
    if (!resourcePlan.valid) {
      throw new Error(`Invalid active spell resource: ${(resourcePlan.errors || []).join(", ")}`);
    }
    operations.push(...resourcePlan.operations);
    if (casterItem) byId.set(payload.casterId, casterItem);
  }
  if (!prismaticWallResolution && action?.concentrationAction === "dismiss") {
    operations.push(
      {
        type: "concentration:break",
        casterIds: [payload.casterId],
        reference: payload.instanceId,
      },
      {
        type: "spell:remove-instance",
        targetIds: [payload.casterId],
        instanceId: payload.instanceId,
      },
    );
  }
  const linkedEffectOutcome = activeResolutionOutcome(
    normalizedPayload,
    ids[0],
    attackOutcome,
  );
  const replaceLinkedEffect = !prismaticWallResolution
    && action?.replaceLinkedEffectId
    && (action.replaceLinkedEffectOnSuccess !== true || linkedEffectOutcome === "passed");
  if (replaceLinkedEffect) {
    const linkedItems = await OBR.scene.items.getItems();
    if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
      throw new Error("scene-epoch-stale-before-active-resolution");
    }
    const removals = buildSpellActiveResolutionLinkedEffectRemovals({
      action,
      payload,
      items: linkedItems,
      targetIds: ids,
    });
    if (removals.length) {
      operations.push({ type: "condition:remove-instances", removals });
    }
  }
  const sideEffects = [{
    type: "spell-active-resolution:validate",
    ...commitInput,
    naturalStormBonus: naturalStormBonus === true,
  }];
  if (staticZoneShortening?.endsSpell) {
    sideEffects.push({
      type: "static-zone:remove-ended",
      selectors: [{
        instanceId: payload.instanceId,
        casterId: payload.casterId,
      }],
    });
  } else if (staticZoneShortening?.preview) {
    sideEffects.push({
      type: "static-zone:reorient",
      zoneItemId: payload.zoneItemId,
      instanceId: payload.instanceId,
      ruleId: staticZoneShortening.ruleId,
      casterId: payload.casterId,
      preview: staticZoneShortening.preview,
    });
  }
  if (!prismaticWallResolution && action?.moveRootToTarget === true && ids.length === 1 && payload?.zoneItemId) {
    const target = byId.get(ids[0]);
    const targetPosition = target?.position;
    if (targetPosition && Number.isFinite(Number(targetPosition.x)) && Number.isFinite(Number(targetPosition.y))) {
      sideEffects.push({
        type: "token:teleport",
        targetId: payload.zoneItemId,
        position: { x: Number(targetPosition.x), y: Number(targetPosition.y) },
        skipAnimation: true,
      });
    }
  }
  if (action?.childZone?.ruleChoice) {
    sideEffects.push({
      type: "static-zone:set-rule-choice",
      selector: { instanceId: payload.instanceId },
      ruleChoice: action.childZone.ruleChoice,
      requireMatch: true,
    });
  }
  let prismaticWallHistory = null;
  if (prismaticWallResolution) {
    const casterItem = byId.get(payload.casterId);
    const parent = prismaticWallSpellEntry(casterItem, payload);
    if (!parent) throw new Error("prismatic-wall-parent-missing");
    const liveState = prismaticWallStateFromCastContext(parent.castContext);
    const snapshotState = prismaticWallStateFromCastContext(payload.castContext);
    if (
      liveState.shape !== snapshotState.shape
      || JSON.stringify(liveState.remainingLayers) !== JSON.stringify(snapshotState.remainingLayers)
      || JSON.stringify(liveState.exemptCreatureIds) !== JSON.stringify(snapshotState.exemptCreatureIds)
    ) {
      throw new Error("prismatic-wall-state-stale");
    }
    const sourceName = String(parent.casterName || payload.casterName || "").trim();
    const isLayerManagement = action?.resolutionKind === "prismatic-wall-layers";
    let traversalExempt = false;
    let nextCastContext = null;
    if (isLayerManagement) {
      const plan = prismaticWallLayerManagementPlan({
        remainingLayers: liveState.remainingLayers,
        layerId,
      });
      if (!plan.valid) {
        throw new Error(`prismatic-wall-layer-invalid: ${(plan.errors || []).join(", ")}`);
      }
      nextCastContext = {
        ...(parent.castContext && typeof parent.castContext === "object"
          ? cloneValue(parent.castContext)
          : {}),
        prismaticWall: {
          ...liveState,
          remainingLayers: plan.remainingLayers,
        },
      };
      prismaticWallHistory = {
        command: "layer-management",
        layerId: String(layerId || "").trim(),
        layerLabel: plan.layer?.label || String(layerId || "").trim(),
        remainingLayersBefore: liveState.remainingLayers,
        remainingLayersAfter: plan.remainingLayers,
      };
    } else {
      const targetId = ids[0];
      const exempt = liveState.exemptCreatureIds.includes(targetId);
      traversalExempt = exempt;
      const plan = prismaticWallTraversalPlan({
        targetId,
        remainingLayers: liveState.remainingLayers,
        outcomes: layerOutcomes,
        damageTotals: layerDamage,
        parentEffectId: payload.instanceId,
        sourceId: payload.casterId,
        sourceName,
        exempt,
      });
      if (!plan.valid) {
        throw new Error(`prismatic-wall-traversal-invalid: ${(plan.errors || []).map((error) => error.code || error).join(", ")}`);
      }
      const target = byId.get(targetId);
      const targetPlan = plan.targetPlans?.[0] || null;
      const currentHpById = new Map();
      for (const contribution of targetPlan?.damageContributions || []) {
        const item = byId.get(contribution.targetId);
        const meta = item?.metadata?.[`${ID}/meta`] || {};
        const amount = Math.max(0, Math.floor(Number(contribution.amount) || 0));
        if (amount <= 0) continue;
        if (
          !item
          || !Object.prototype.hasOwnProperty.call(meta, "hp")
          || !Object.prototype.hasOwnProperty.call(meta, "hpMax")
        ) {
          throw new Error("active-resolution-hp-required");
        }
        const currentHp = currentHpById.has(contribution.targetId)
          ? currentHpById.get(contribution.targetId)
          : meta.hp;
        const hpChange = calculateQuickHPChange({
          mode: QUICK_HP_MODES.DAMAGE,
          value: amount,
          factor: QUICK_HP_FACTORS.FULL,
          hp: currentHp,
          hpMax: meta.hpMax,
        });
        currentHpById.set(contribution.targetId, hpChange.afterHP);
        const existingPatch = metadataPatches.find((patch) => patch.id === contribution.targetId);
        if (hpChange.changed) {
          if (existingPatch) {
            existingPatch.fields.hp.value = hpChange.afterHP;
            existingPatch.fields.hpMax.value = hpChange.hpMax;
          } else {
            metadataPatches.push({
              id: contribution.targetId,
              fields: {
                hp: {
                  expected: metadataSnapshot(meta, "hp"),
                  value: hpChange.afterHP,
                },
                hpMax: {
                  expected: metadataSnapshot(meta, "hpMax"),
                  value: hpChange.hpMax,
                },
              },
            });
          }
        }
      }
      if (targetPlan) {
        const totalDamage = (targetPlan.damageContributions || [])
          .reduce((sum, contribution) => sum + Math.max(0, Number(contribution.amount) || 0), 0);
        resolutionDamageByTarget.set(targetId, {
          outcome: targetPlan.layers.map((entry) => `${entry.layerId}:${entry.outcome}`).join(","),
          damage: { amount: totalDamage, factor: 1 },
          prismaticContributions: cloneValue(targetPlan.damageContributions || []),
        });
      }
      const conditionOperations = [];
      for (const application of targetPlan?.conditionApplications || []) {
        const effectId = application.options?.effectId;
        if (hasActiveEffect(target, effectId)) continue;
        conditionOperations.push({
          type: "condition:add",
          targetIds: application.targetIds,
          conditionName: application.conditionName,
          options: cloneValue(application.options),
        });
      }
      if (conditionOperations.length) {
        operations.push(...conditionOperations);
        operations.push({
          type: "condition:automate",
          subjectIds: [targetId],
        });
      }
      for (const patch of metadataPatches) {
        const item = byId.get(patch.id);
        const meta = item?.metadata?.[`${ID}/meta`] || {};
        const zeroAction = resolveZeroHPUnconsciousAction(
          { ...meta, hp: patch.fields.hp.value, hpMax: patch.fields.hpMax.value },
          getConditionInstances(meta.conditions || {}),
        );
        if (zeroAction.add) unconsciousIds.push(patch.id);
        unconsciousRemovals.push(...zeroAction.removeInstanceIds.map((removedInstanceId) => ({
          itemId: patch.id,
          instanceId: removedInstanceId,
        })));
        if (patch.fields.hp.value < patch.fields.hp.expected.value) {
          for (const removedInstanceId of resolveDamageEndsConditionRemovals(
            getConditionInstances(meta.conditions || {}),
          )) {
            unconsciousRemovals.push({ itemId: patch.id, instanceId: removedInstanceId });
          }
        }
      }
      nextCastContext = prismaticWallTraversalMarker(parent.castContext, traversalId);
      prismaticWallHistory = {
        command: "traversal",
        traversalId: String(traversalId || "").trim(),
        targetId,
        exempt,
        layers: cloneValue(targetPlan?.layers || []),
        damageContributions: cloneValue(targetPlan?.damageContributions || []),
      };
    }
    if (isLayerManagement || !traversalExempt) {
      operations.push(prismaticWallSpellUpsertOperation({
        parent,
        payload,
        castContext: nextCastContext,
      }));
    }
  } else if (action?.resolutionKind === "child-zone") {
    const childZone = action.childZone || {};
    const [parentZone] = payload.zoneItemId
      ? await OBR.scene.items.getItems([payload.zoneItemId])
      : [];
    const parentArea = translatedZoneArea(parentZone);
    const activationId = String(
      placement?.activationId
      || `${payload.instanceId}:${payload.actionId}:${Date.now()}`,
    ).trim();
    const childItems = childPlacementEntries(placement).map((preview, index) =>
      buildStaticSpellChildZoneItem({
        ruleId: childZone.placementRuleId || action.placementRuleId,
        instanceId: payload.instanceId,
        casterId: payload.casterId,
        parentId: payload.zoneItemId,
        parentArea,
        spellName: payload.spellName,
        preview,
        childKind: childZone.childKind,
        childIndex: index,
        activationId,
        sceneEpoch: payload.sceneEpoch,
        variant: childZone.ruleChoice || "",
        depthRoll: preview?.depthRoll,
      })
    );
    sideEffects.push({
      type: "static-zone:child-zones",
      parentZoneId: payload.zoneItemId,
      parentInstanceId: payload.instanceId,
      casterId: payload.casterId,
      items: childItems,
      ...(childZone.replaceChildKind
        ? { replaceChildKind: childZone.replaceChildKind }
        : {}),
      ...(childZone.singleActivation === true
        ? { singleActivation: true }
        : {}),
    });
    const failureEffect = childZone.failureEffect;
    const failedIds = ids.filter((targetId) => outcomes?.[targetId] === "failed");
    if (failureEffect && failedIds.length) {
      operations.push({
        type: "condition:add",
        targetIds: failedIds,
        conditionName: String(failureEffect.label || "Caduto nella fessura").trim(),
        options: {
          sourceId: payload.casterId,
          sourceName: payload.casterName,
          parentEffectId: payload.instanceId,
          type: "spell",
          effectId: String(failureEffect.effectId || `${payload.spellId}-${childZone.childKind}`).trim(),
          effectDetail: String(failureEffect.detail || "").trim(),
          manualRemoval: true,
          endsParentOnRemoval: true,
          expiry: { mode: "concentration" },
        },
      });
      operations.push({ type: "condition:automate", subjectIds: failedIds });
    }
  } else {
    if (action?.resolutionKind === "single-heal") {
      const targetId = ids[0];
      const item = byId.get(targetId);
      const meta = item?.metadata?.[`${ID}/meta`] || {};
      const healing = resolveSpellActiveResolutionHealing({
        action,
        slotLevel: payload.slotLevel,
        roll: damageRoll,
      });
      if (!healing.valid) throw new Error("active-resolution-healing-invalid");
      if (!item
        || !Object.prototype.hasOwnProperty.call(meta, "hp")
        || !Object.prototype.hasOwnProperty.call(meta, "hpMax")) {
        throw new Error("active-resolution-hp-required");
      }
      const hpChange = calculateQuickHPChange({
        mode: QUICK_HP_MODES.HEAL,
        value: healing.amount,
        factor: QUICK_HP_FACTORS.FULL,
        hp: meta.hp,
        hpMax: meta.hpMax,
      });
      resolutionHealingByTarget.set(targetId, { healing, hpChange });
      if (hpChange.changed) {
        metadataPatches.push({
          id: targetId,
          fields: {
            hp: {
              expected: metadataSnapshot(meta, "hp"),
              value: hpChange.afterHP,
            },
            hpMax: {
              expected: metadataSnapshot(meta, "hpMax"),
              value: hpChange.hpMax,
            },
          },
        });
      }
      const zeroAction = resolveZeroHPUnconsciousAction(
        { ...meta, hp: hpChange.afterHP, hpMax: hpChange.hpMax },
        getConditionInstances(meta.conditions || {}),
      );
      unconsciousRemovals.push(...zeroAction.removeInstanceIds.map((instanceId) => ({
        itemId: targetId,
        instanceId,
      })));
    } else {
      const resolutionEntries = attackEntries.length
        ? attackEntries
        : ids.map((targetId) => ({ targetId, attackOutcome, damageRoll }));
      const currentHpById = new Map();
      for (const entry of resolutionEntries) {
        const targetId = entry.targetId;
        const item = byId.get(targetId);
        const meta = item?.metadata?.[`${ID}/meta`] || {};
        const outcome = action?.resolutionKind === "single-attack"
          ? entry.attackOutcome
          : activeResolutionOutcome(normalizedPayload, targetId, attackOutcome);
        if (!action?.damage) {
          resolutionDamageByTarget.set(targetId, { damage: null, outcome });
          continue;
        }
        const damage = resolveSpellActiveResolutionDamage({
          action,
          slotLevel: payload.slotLevel,
          outcome,
          roll: action?.resolutionKind === "single-attack" ? entry.damageRoll : damageRoll,
        });
        if (!damage.valid) throw new Error("active-resolution-damage-invalid");
        resolutionDamageByTarget.set(targetId, { damage, outcome });
        if (damage.amount <= 0) continue;
        if (!item
          || !Object.prototype.hasOwnProperty.call(meta, "hp")
          || !Object.prototype.hasOwnProperty.call(meta, "hpMax")) {
          throw new Error("active-resolution-hp-required");
        }
        const currentHp = currentHpById.has(targetId)
          ? currentHpById.get(targetId)
          : meta.hp;
        const hpChange = calculateQuickHPChange({
          mode: QUICK_HP_MODES.DAMAGE,
          value: damage.amount,
          factor: QUICK_HP_FACTORS.FULL,
          hp: currentHp,
          hpMax: meta.hpMax,
        });
        currentHpById.set(targetId, hpChange.afterHP);
        if (!hpChange.changed) continue;
        const existingPatch = metadataPatches.find((patch) => patch.id === targetId);
        if (existingPatch) {
          existingPatch.fields.hp.value = hpChange.afterHP;
          existingPatch.fields.hpMax.value = hpChange.hpMax;
        } else {
          metadataPatches.push({
            id: targetId,
            fields: {
              hp: {
                expected: metadataSnapshot(meta, "hp"),
                value: hpChange.afterHP,
              },
              hpMax: {
                expected: metadataSnapshot(meta, "hpMax"),
                value: hpChange.hpMax,
              },
            },
          });
        }
      }
    }
    const casterHealingRatio = Number(action?.casterHealingFromAppliedDamage) || 0;
    if (casterHealingRatio > 0) {
      const damageChanges = ids.map((targetId) => ({
        requested: resolutionDamageByTarget.get(targetId)?.damage?.amount,
      }));
      const [casterItem] = await OBR.scene.items.getItems([payload.casterId]);
      if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
        throw new Error("scene-epoch-stale-before-active-resolution");
      }
      const casterMeta = casterItem?.metadata?.[`${ID}/meta`] || {};
      if (casterItem
        && Object.prototype.hasOwnProperty.call(casterMeta, "hp")
        && Object.prototype.hasOwnProperty.call(casterMeta, "hpMax")) {
        const healingChange = spellCasterHealingChange({
          damageChanges,
          ratio: casterHealingRatio,
          hp: casterMeta.hp,
          hpMax: casterMeta.hpMax,
        });
        if (healingChange.changed) {
          metadataPatches.push({
            id: payload.casterId,
            fields: {
              hp: {
                expected: metadataSnapshot(casterMeta, "hp"),
                value: healingChange.afterHP,
              },
              hpMax: {
                expected: metadataSnapshot(casterMeta, "hpMax"),
                value: healingChange.hpMax,
              },
            },
          });
          byId.set(payload.casterId, casterItem);
        }
      }
    }
    for (const patch of metadataPatches) {
      const item = byId.get(patch.id);
      const meta = item?.metadata?.[`${ID}/meta`] || {};
      const zeroAction = resolveZeroHPUnconsciousAction(
        { ...meta, hp: patch.fields.hp.value, hpMax: patch.fields.hpMax.value },
        getConditionInstances(meta.conditions || {}),
      );
      if (zeroAction.add) unconsciousIds.push(patch.id);
      unconsciousRemovals.push(...zeroAction.removeInstanceIds.map((instanceId) => ({
        itemId: patch.id,
        instanceId,
      })));
      if (patch.fields?.hp?.value < patch.fields?.hp?.expected?.value) {
        for (const instanceId of resolveDamageEndsConditionRemovals(getConditionInstances(meta.conditions || {}))) {
          unconsciousRemovals.push({ itemId: patch.id, instanceId });
        }
      }
    }
    operations.push(...buildSpellActiveResolutionPostDamageOperations({
      action,
      payload,
      targetIds: ids,
    }));
    operations.push(...buildSpellActiveResolutionFailureOperations({
      action,
      payload,
      targetIds: ids,
      outcomes,
    }));
    operations.push(...buildSpellActiveResolutionSuccessOperations({
      action,
      payload,
      targetIds: ids,
      outcomes,
    }));
    const actionEffects = Array.isArray(action?.effects) ? action.effects : [];
    const hitEffectTargetIds = attackEntries.length
      ? normalizeActiveResolutionTargetIds(
        attackEntries
          .filter((entry) => ["hit", "critical"].includes(entry.attackOutcome))
          .map((entry) => entry.targetId),
      )
      : attackOutcome === "hit" && action?.resolutionKind === "single-attack"
        ? ids
        : [];
    if (hitEffectTargetIds.length && action?.effectOn === "hit") {
      for (const effect of actionEffects) {
        const conditionName = spellEffectConditionName(effect);
        if (!conditionName) continue;
        operations.push({
          type: "condition:add",
          targetIds: hitEffectTargetIds,
          conditionName,
          options: spellEffectConditionOptions(
            effect,
            {
              sourceId: payload.casterId,
              sourceName: payload.casterName,
              expiry: effect.expiry || { mode: "manual" },
            },
            payload.instanceId,
          ),
        });
      }
      if (operations.some((operation) => operation.type === "condition:add")) {
        operations.push({ type: "condition:automate", subjectIds: hitEffectTargetIds });
      }
    }
  }
  if (unconsciousIds.length) {
    operations.push({
      type: "condition:add",
      targetIds: unconsciousIds,
      conditionName: "Privo di sensi",
      options: { type: ZERO_HP_UNCONSCIOUS_TYPE, expiry: { mode: "manual" } },
    });
    operations.push({ type: "condition:automate", subjectIds: unconsciousIds });
  }
  if (unconsciousRemovals.length) {
    operations.push({ type: "condition:remove-instances", removals: unconsciousRemovals });
  }
  const spellName = String(payload.spellName || payload.spellId).trim();
  const actionLabel = String(action.buttonLabel || action.label || "Attivazione").trim();
  const causalTargets = ids.map((targetId) => {
    const item = byId.get(targetId);
    const resolution = resolutionDamageByTarget.get(targetId);
    const damage = resolution?.damage;
    const healing = resolutionHealingByTarget.get(targetId)?.healing;
    const patch = metadataPatches.find((entry) => entry.id === targetId);
    const meta = item?.metadata?.[`${ID}/meta`] || {};
    const beforeHP = Number(meta.hp);
    const afterHP = patch ? Number(patch.fields.hp.value) : beforeHP;
    const appliedHpDelta = Number.isFinite(beforeHP) && Number.isFinite(afterHP)
      ? afterHP - beforeHP
      : undefined;
    return {
      id: targetId,
      ...(item?.name ? { name: item.name } : {}),
      ...(resolution?.outcome ? { outcome: resolution.outcome } : {}),
      ...(damage ? { requestedDamage: damage.amount, damageFactor: damage.factor } : {}),
      ...(resolution?.prismaticContributions
        ? { prismaticContributions: cloneValue(resolution.prismaticContributions) }
        : {}),
      ...(healing ? { requestedHealing: healing.amount } : {}),
      ...(appliedHpDelta !== undefined ? { appliedHpDelta } : {}),
    };
  });
  const causalAction = {
    ...(action || {}),
    ...(prismaticWallResolution
      ? {
        layerOutcomes: cloneValue(layerOutcomes),
        layerDamage: cloneValue(layerDamage),
        layerId: String(layerId || "").trim(),
        traversalId: String(traversalId || "").trim(),
      }
      : action?.resolutionKind === "single-heal"
      ? { healingRoll: damageRoll }
      : action?.resolutionKind === "single-attack" && attackEntries.length === 1
      ? { damageRoll: attackEntries[0].damageRoll, attackOutcome: attackEntries[0].attackOutcome }
      : { damageRoll }),
  };
  const mutation = await runEffectsMutation(operations, {
    kind: "spell-active-resolution",
    label: `Attivazione: ${spellName} · ${actionLabel}`,
    targetIds: [payload.casterId, ...ids],
    metadataPatches,
    sideEffects,
    ...(sceneIdentity ? { sceneIdentity } : {}),
    ...(commandId ? { commandId } : {}),
    history: {
      kind: "spell-active-resolution",
      label: `Attivazione: ${spellName} · ${actionLabel}`,
      payload: {
        type: payload.type,
        spellId: payload.spellId,
        instanceId: payload.instanceId,
        casterId: payload.casterId,
        actionId: payload.actionId,
        slotLevel: payload.slotLevel,
        targetIds: ids,
        outcomes,
        ...(action?.resolutionKind === "single-save" && saveAbility
          ? { saveAbility: String(saveAbility).trim().toLowerCase() }
          : {}),
        attackOutcome: String(attackOutcome || ""),
        ...(action?.resolutionKind === "single-heal"
          ? { healingRoll: Math.max(0, Math.floor(Number(damageRoll) || 0)) }
          : { damageRoll: Math.max(0, Math.floor(Number(damageRoll) || 0)) }),
        attacks: attackEntries,
        ...(prismaticWallHistory ? { prismaticWall: prismaticWallHistory } : {}),
        ...(action?.shortenStaticZone ? { shorteningFrom: String(shorteningFrom || action.shortenStaticZone.from || "end") } : {}),
        naturalStormBonus: naturalStormBonus === true,
        causality: buildSpellCausality({
          eventType: "resolution",
          spellId: payload.spellId,
          spellName: payload.spellName,
          instanceId: payload.instanceId,
          slotLevel: payload.slotLevel,
          phase: payload.castContext?.phase || payload.phase,
          casterId: payload.casterId,
          casterName: payload.casterName,
          targets: causalTargets,
          targetIds: ids,
          outcomes,
          attacks: attackEntries,
          actionId: payload.actionId,
          action: causalAction,
          concentrationAction: action?.concentrationAction,
          concentrationInstanceId: payload.instanceId,
          zone: payload.zoneItemId
            ? {
              action: action?.childZone ? "resolve" : undefined,
              zoneItemId: payload.zoneItemId,
              ruleId: action?.placementRuleId || action?.childZone?.placementRuleId,
            }
            : undefined,
        }),
      },
    },
  });
  requireAppliedEffectsMutation(mutation);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory(mutation, {
      ...mutation,
      stale: true,
      postCommitPending: true,
    });
  }
  await refreshConditionLabels(mutation.changedIds || []);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory(mutation, {
      ...mutation,
      stale: true,
      postCommitPending: true,
    });
  }
  const execution = attachSpellExecutionHistory(mutation, mutation);
  return action?.successNotice && linkedEffectOutcome === "passed"
    ? { ...execution, manualNotice: String(action.successNotice).trim() }
    : execution;
}

export async function executeSpellBoardTokenStateUpdate({
  group = null,
  hp = undefined,
  sceneEpoch = null,
  sceneIdentity = null,
  commandId = "",
  isCurrent = null,
} = {}) {
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-board-token-update");
  }
  const instanceId = String(group?.instanceId || "").trim();
  const casterId = String(group?.casterId || "").trim();
  const itemId = String(group?.itemId || "").trim();
  if (!instanceId || !casterId) throw new Error("Invalid spell board token state: context-required");
  const rule = getSpellBoardTokenRule(group?.spellId);
  const endsAtZero = rule?.spellId === "arcane-hand"
    && hp !== undefined
    && Number.isFinite(Number(hp))
    && Number(hp) === 0;
  const removesAtZero = (endsAtZero || rule?.spellId === "animate-objects")
    && hp !== undefined
    && Number.isFinite(Number(hp))
    && Number(hp) === 0;
  const operations = endsAtZero
    ? [
      {
        type: "concentration:break",
        casterIds: [casterId],
        reference: instanceId,
      },
      {
        type: "spell:remove-instance",
        targetIds: [casterId],
        instanceId,
      },
    ]
    : [];
  const label = endsAtZero
    ? `Terminata pedina: ${String(group?.name || "Incantesimo").trim()}`
    : `Aggiorna pedina: ${String(group?.name || "Incantesimo").trim()}`;
  const mutation = await runEffectsMutation(operations, {
    kind: "spell-board-token",
    label,
    targetIds: [casterId],
    sideEffects: [{
      type: "spell-board-token:update-state",
      instanceId,
      ...(itemId ? { itemId } : {}),
      hp,
      ...(removesAtZero ? { removeWhenZero: true } : {}),
    }],
    history: {
      kind: "spell-board-token",
      label,
      payload: {
        causality: buildSpellCausality({
          eventType: "board-token-update",
          spellId: group?.spellId,
          spellName: group?.name,
          instanceId,
          slotLevel: group?.castContext?.slotLevel,
          phase: group?.castContext?.phase,
          casterId,
          casterName: group?.casterName,
          actionLabel: label,
          concentrationAction: endsAtZero ? "break" : undefined,
          concentrationInstanceId: instanceId,
        }),
      },
    },
    ...(sceneIdentity ? { sceneIdentity } : {}),
    ...(commandId ? { commandId } : {}),
  });
  requireAppliedEffectsMutation(mutation);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory(
      mutation.commitResult?.sideEffectChanges || [],
      { ...mutation, stale: true, postCommitPending: true },
    );
  }
  return attachSpellExecutionHistory(
    mutation.commitResult?.sideEffectChanges || [],
    mutation,
  );
}

export async function executeSpellBoardTokenRecreate({
  group = null,
  position = null,
  sceneEpoch = null,
  sceneIdentity = null,
  commandId = "",
  isCurrent = null,
} = {}) {
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-board-token-recreate");
  }
  const instanceId = String(group?.instanceId || "").trim();
  const casterId = String(group?.casterId || "").trim();
  const rule = getSpellBoardTokenRule(group?.spellId);
  if (
    !instanceId
    || !casterId
    || !rule
    || !Number.isFinite(Number(position?.x))
    || !Number.isFinite(Number(position?.y))
  ) {
    throw new Error("Invalid spell board token recreation: context-required");
  }
  const label = `Ricrea pedina: ${String(group?.name || rule.label).trim()}`;
  const mutation = await runEffectsMutation([], {
    kind: "spell-board-token",
    label,
    targetIds: [casterId],
    sideEffects: [{
      type: "spell-board-token:place",
      entityId: createSpellBoardTokenId(),
      spellId: rule.spellId,
      instanceId,
      casterId,
      slotLevel: group?.castContext?.slotLevel,
      position: { x: Number(position.x), y: Number(position.y) },
    }],
    history: {
      kind: "spell-board-token",
      label,
      payload: {
        causality: buildSpellCausality({
          eventType: "board-token-update",
          spellId: rule.spellId,
          spellName: group?.name || rule.label,
          instanceId,
          slotLevel: group?.castContext?.slotLevel,
          phase: group?.castContext?.phase,
          casterId,
          casterName: group?.casterName,
          action: { id: "recreate", label },
        }),
      },
    },
    ...(sceneIdentity ? { sceneIdentity } : {}),
    ...(commandId ? { commandId } : {}),
  });
  requireAppliedEffectsMutation(mutation);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory(
      mutation.commitResult?.sideEffectChanges || [],
      { ...mutation, stale: true, postCommitPending: true },
    );
  }
  return attachSpellExecutionHistory(
    mutation.commitResult?.sideEffectChanges || [],
    mutation,
  );
}

export async function executeSpellApplication({
  spell,
  enteredName = "",
  turns = 1,
  casterId = "",
  targetIds = [],
  castContext = {},
  selectedChoice = "",
  phasePlan = null,
  applyAutomatedConditions = true,
  activeConcentration = null,
  historyLabel = "",
  requestedConcentration = false,
  appliedAt = undefined,
  casterName = "",
  sceneEpoch = null,
  sceneIdentity = null,
  commandId = "",
  isCurrent = null,
  attackOutcome = undefined,
  saveOutcomes = undefined,
  saveOutcome = "",
  damageValue = undefined,
  primaryDamageValue = undefined,
  primaryTargetId = "",
  manualAttackOutcomeRequired = false,
  ignoreTargetLimit = false,
} = {}) {
  const intent = buildSpellApplicationIntent({
    spell,
    enteredName,
    turns,
    casterId,
    targetIds,
    castContext,
    selectedChoice,
    phasePlan,
    applyAutomatedConditions,
    activeConcentration,
    historyLabel,
    requestedConcentration,
    attackOutcome,
    saveOutcomes,
    saveOutcome,
    damageValue,
    primaryDamageValue,
    primaryTargetId,
    manualAttackOutcomeRequired,
    ignoreTargetLimit,
  });
  if (!intent) return [];

  if (
    intent.phasePlan?.phase === "resolve"
    && intent.attackOutcome === "miss"
    && intent.phasePlan.attack?.consumeOnMiss !== true
  ) {
    return spellApplicationNoop("miss", "prepared-attack-miss", { pending: true });
  }

  const instanceId = String(activeConcentration?.instanceId || "").trim()
    || createSpellInstanceId();
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-spell-application");
  }
  if (
    intent.phasePlan?.phase === "resolve"
    && activeConcentration?.instanceId
    && !(await preparedInstanceIsCurrent(casterId, activeConcentration, spell?.id))
  ) {
    return spellApplicationNoop("stale", "prepared-instance-stale", { stale: true });
  }
  const resolvedAppliedAt = appliedAt === undefined
    ? await getCurrentSpellAppliedAt()
    : appliedAt;
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-spell-application");
  }
  const applicationPlan = buildSpellApplicationPlan({
    intent,
    instanceId,
    appliedAt: resolvedAppliedAt,
    casterName,
  });
  const initialDamage = applicationPlan.initialDamage;
  const manualDamage = manualDamageValue(damageValue);
  if (
    applicationPlan.damageRequired
    && intent.manualAttackOutcomeRequired === true
    && intent.attackOutcome !== "miss"
    && manualDamage === null
  ) {
    throw new Error("spell-initial-damage-required");
  }
  const initialDamageMutation = initialDamage && intent.attackOutcome !== "miss"
    ? await buildPreparedInitialDamageMutation({
      targetIds: intent.subjects,
      amount: manualDamage,
    })
    : { metadataPatches: [], operations: [], applied: 0, targets: [] };
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    throw new Error("scene-epoch-stale-before-spell-application");
  }
  if (
    intent.phasePlan?.phase === "resolve"
    && activeConcentration?.instanceId
    && !(await preparedInstanceIsCurrent(casterId, activeConcentration, spell?.id))
  ) {
    return spellApplicationNoop("stale", "prepared-instance-stale", { stale: true });
  }
  const banishmentEligibleTargetIds = banishmentThresholdTargetIds({
    spell,
    phasePlan: applicationPlan.phasePlan,
    damageTargets: initialDamageMutation.targets,
  });
  const applicationOperations = [
    ...scopeBanishmentOperations(applicationPlan.operations, banishmentEligibleTargetIds),
    ...initialDamageMutation.operations,
  ];
  const removeReplacedZones = intent.wantsConcentration
    && applicationPlan.concentrationAction === "replace"
    && casterId;
  const boardTokenRule = applicationPlan.phasePlan?.phase === "prepare"
    ? null
    : getSpellBoardTokenRule(spell);
  const sideEffects = [];
  if (removeReplacedZones) {
    sideEffects.push({
      type: "static-zone:remove-ended",
      selectors: [{ casterId }],
    });
  }
  const mutation = await runEffectsMutation(applicationOperations, {
    kind: "spell",
    label: applicationPlan.historyLabel,
    targetIds: [casterId, ...targetIds],
    metadataPatches: initialDamageMutation.metadataPatches,
    sideEffects,
    history: {
      kind: "spell",
      label: applicationPlan.historyLabel,
      payload: {
        causality: buildSpellCausality({
          eventType: applicationPlan.phasePlan?.phase === "prepare"
            ? "prepare"
            : applicationPlan.phasePlan?.phase === "resolve"
              ? "resolution"
              : "application/cast",
          spellId: spell?.id,
          spellName: spell?.displayName || spell?.name || intent.name,
          instanceId,
          slotLevel: intent.persistedCastContext?.slotLevel || castContext?.slotLevel,
          phase: applicationPlan.phasePlan?.phase || intent.persistedCastContext?.phase,
          casterId,
          casterName,
          targetIds: intent.subjects,
          actionId: castContext?.actionId || intent.persistedCastContext?.actionId,
          actionLabel: applicationPlan.historyLabel,
          concentrationAction: intent.wantsConcentration
            ? applicationPlan.concentrationAction
            : undefined,
          concentrationInstanceId: instanceId,
          attackOutcome: intent.attackOutcome || undefined,
          damageRoll: initialDamage ? initialDamageMutation.applied : undefined,
          outcomes: intent.saveOutcomes,
          targets: initialDamageMutation.targets.length
            ? initialDamageMutation.targets
            : intent.subjects,
          ...(initialDamage
            ? {
              initialDamage: {
                dice: initialDamage.dice,
                type: initialDamage.type,
                amount: initialDamageMutation.applied,
                targets: initialDamageMutation.targets,
              },
            }
            : {}),
          ...(Object.keys(intent.saveOutcomes || {}).length
            ? { saveOutcomes: intent.saveOutcomes }
            : {}),
          ...(banishmentEligibleTargetIds !== null
            ? { banishmentEligibleTargetIds }
            : {}),
        }),
      },
    },
    ...(sceneIdentity ? { sceneIdentity } : {}),
    ...(commandId ? { commandId } : {}),
  });
  requireAppliedEffectsMutation(mutation);
  const changedIds = mutation.changedIds;
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory([...changedIds], {
      ...mutation,
      stale: true,
      postCommitPending: true,
    });
  }
  if (applicationPlan.phasePlan?.phase !== "prepare" && !boardTokenRule) {
    void emitMatchedSpellVisual({
      spellId: spell?.id,
      casterId,
      targetIds,
      eventId: instanceId,
      lifecycleId: instanceId,
      sceneEpoch,
    }).catch((error) => {
      console.warn("[spell] matched visual:", error?.message || error);
    });
  }
  await refreshConditionLabels(changedIds);
  if (typeof isCurrent === "function" && sceneEpoch != null && !isCurrent(sceneEpoch)) {
    return attachSpellExecutionHistory([...changedIds], {
      ...mutation,
      stale: true,
      postCommitPending: true,
    });
  }
  return attachSpellExecutionHistory([...changedIds], mutation);
}
